/**
 * Created by fengyang on 2017/5/18.
 */
//处理特殊字符的方法
layui.use(['element'], function() {
	var element = layui.element(), $ = layui.jquery;
	
	(function($){  
	    var _ajax=$.ajax;  
	    $.ajax=function(opt){
	        //备份opt中error和success方法  
	        var fn = {  
	            error:function(xhr,error,msg){
	            	console.log(xhr.status);
	            	if(xhr.status=="0"){
	            		layer.alert("请求失败，网络不通或没有服务！", {
                            title:'操作提示',
                            icon:5,
                            btnAlign:'c',
                            skin: 'layui-layer-molv' //样式类名
                            ,closeBtn: 0
                        }, function(){
                            layer.closeAll();
                        });
	            	}else if(xhr.status=="901"){
                       //超时跳转到登录页面
                        if(top.frames.length>0){
                            top.location.reload();
                        }
                    }else{
                        //error情况
                        layer.alert("系统错误，请稍后操作！", {
                            title:'操作提示',
                            icon:5,
                            btnAlign:'c',
                            skin: 'layui-layer-molv' //样式类名
                            ,closeBtn: 0
                        }, function(){
                            layer.closeAll();
                        });
                    }
	            }
	        };
	        if(opt.error){  
	            fn.error=opt.error;  
	        }  
	        //扩展增强处理  
	        var _opt = $.extend(opt,{  
	            error:function(XMLHttpRequest, textStatus, errorThrown){  
	                fn.error(XMLHttpRequest, textStatus, errorThrown);  
	            }  
	        });  
	        _ajax(_opt);  
	    };  
	})(layui.jquery);
});
function escapeHtml(string) {
    var entityMap = {
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': '&quot;',
        "'": '&#39;',
        "/": '&#x2F;'
    };
    return String(string).replace(/[&<>"'\/]/g, function (s) {
        return entityMap[s];
    });
}

//日期转换
Date.prototype.Format = function (fmt) {
    var o = {
        "M+": this.getMonth() + 1, //月份
        "d+": this.getDate(), //日
        "h+": this.getHours(), //小时
        "m+": this.getMinutes(), //分
        "s+": this.getSeconds(), //秒
        "q+": Math.floor((this.getMonth() + 3) / 3), //季度
        "S": this.getMilliseconds() //毫秒
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
        if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
}
/*消息提示内容 msg为消息内容，status为状态，isReload判断是否进行页面重载，icon是加载成功时带图标的提示*/
function msgTip(msg,status,isReload,icon) {
    //表示操作失败
    if(status=="0"){
        //表示失败
        layer.alert(msg, {
            title:'操作提示',
            icon:5,
            btnAlign:'c',
            skin: 'layui-layer-molv' //样式类名
            ,closeBtn: 0
        }, function(){
            layer.closeAll();
        });
    }else if(status=="1"){
       //表示成功
        if(icon){
            layer.alert(msg, {
                title:'温馨提示',
                icon:6,
                btnAlign:'c',
                skin: 'layui-layer-molv' //样式类名
                ,closeBtn: 0
            }, function(){
                layer.closeAll();
                if(isReload){
                    location.reload();
                }
            });
        }else{
            if(isReload){
                //layer.msg(msg);
                location.reload();
            }
        }
    }else if(status=="2"){
        //error情况
        layer.alert("对不起，请求访问失败，请稍后操作！", {
            title:'操作提示',
            icon:5,
            btnAlign:'c',
            skin: 'layui-layer-molv' //样式类名
            ,closeBtn: 0
        }, function(){
            layer.closeAll();
        });
    }else if(status=="3"){
        //超时情况
        layer.alert("对不起，请求访问超时，请稍后操作！", {
            title:'操作提示',
            icon:5,
            btnAlign:'c',
            skin: 'layui-layer-molv' //样式类名
            ,closeBtn: 0
        }, function(){
            layer.closeAll();
        });
    }
}


