/**
 * Created by fengyang on 2017/5/18.
 */
layui.use(['form','element','layer','laypage','laydate'], function () {
    var element = layui.element(), layer = layui.layer,$ = layui.jquery,laypage = layui.laypage,laydate = layui.laydate,form=layui.form();
    var layerHeight =$(window).height(); //计算弹框高度使用
    var layerWidth = $(window).width();//计算弹框宽度使用
    //时间筛选
    var start = {
        istoday: false,
        choose: function(datas){
            end.min = datas; //开始日选好后，重置结束日的最小日期
            end.start = datas //将结束日的初始值设定为开始日
        }
    };
    var end = {
        istoday: false,
        choose: function(datas){
            start.max = datas; //结束日选好后，重置开始日的最大日期
        }
    };
    //开始时间事件
    $(document).on("click","#startTime",function () {
        start.elem = this;
        laydate(start);
    });
    //结束时间事件
    $(document).on("click","#endTime",function () {
        end.elem = this;
        laydate(end);
    });

    renderDefList();
    //页面初始化加载默认第一页
    renderProcessList(1,8,"endTime-sort-down",$("#startTime").val(),$("#endTime").val(),$("#flowName").val());



    //详情排序事件
    $(document).on("click",".main-sort",function () {
        //刷新列表
        var sortType =  $(this).attr("data-attr");//获取排序的名称
        renderProcessList(1,8,sortType,$("#startTime").val(),$("#endTime").val(),$("#flowName").val());
        $(this).siblings().show();
        $(this).hide();
    });
    //查询方法
    $(document).on("click","#searchFinishedList",function () {
        var sortType =  $(".main-sort:visible").attr("data-attr");//获取排序的名称
        renderProcessList(1,8,sortType,$("#startTime").val(),$("#endTime").val(),$("#flowName").val());
    });

    //点击事件
    $(document).on("click",".show-detail", function () {
        $(".finished-list").hide();
        $(".task-detail-list").show();
        id = $(this).attr("pid");
        $(".migu-tab li.layui-this").trigger("click");
    });
    $(document).on("click",".return-list", function () {
        $(".finished-list").show();
        $(".task-detail-list").hide();
    });

    //tab点击事件
    $(".migu-tab li").on("click",function () {

        renderInstanceTaskDetails(1,8,id);
    });
    //错误详情展示
    $(document).on("click",".show-reason",function () {
        $("#finishedCauseForm p").html($(this).attr("data-content"));
        var height = parseInt(layerHeight*0.66);
        var width = parseInt(layerWidth*0.40);
        if(layerHeight<400){
            parseInt(layerHeight*0.60);
        }
        if(layerWidth<1000){
            width = parseInt(layerWidth*0.50);
        }
        var causeIndex=layer.open({
            type: 1,
            offset: '10px',
            title: "错误明细展示",
            skin: 'layui-layer-molv',
            content: $("#finishedCauseWin"),
            area: [width+'px', height+'px'],
            btnAlign: 'l',
            btn: ['关闭'],
            yes:function () {
                layer.close(causeIndex);
            }

        });
    });

    //启动参数
    $(document).on("click","a[lay-filter=varProcess]",function () {
        var url = ctx+"/activityFlow/varHisByFlowId/"+$(this).attr("pid");
        var ajaxTimeout =$.ajax({
            url:url,
            method:"POST",
            data:{},
            dataType:"json",
            async:false,
            timeout:6000,
            beforeSend:function(){
                //请求之前的操作
                index = layer.load(2, {
                    shade: [0.5,'#fff'] //0.1透明度的白色背景
                });
            },
            success: function (data) {
                //data = {"jobDate":"2017-10","retryMap":[{"taskId":"001","taskName":"name"}]};
                //成功后的操作
                var height = parseInt(layerHeight*0.60);
                var width = parseInt(layerWidth*0.40);
                var showflowVarIndex=layer.open({
                    type:1,
                    offset:"c",
                    title:"启动参数详情",
                    skin: 'layui-layer-molv',
                    content:$("#flowVarWin"),
                    area: [width+'px', height+'px'],
                    btn: ['关闭'],
                    yes:function () {
                        layer.close(showflowVarIndex);
                    }
                });
                if(data){
                    var temp = [];
                    //拼接字符串
                    $("#jobDate").html(data["jobDate"]);
                    $.each(data["retryMap"], function (i,v) {
                        temp.push('<tr>' +
                            '<td>'+i+'</td>'+
                            '<td>'+v+'</td>'+
                            '</tr>');
                    });
                    if(temp.length>0) {
                        $("#varBody").empty().append(temp.join(""));
                    }else{
                        $("#varBody").empty().append('<tr><td class="text-center" colspan="3">无参数</td></tr>');
                    }
                }else{
                    $("#jobDate").html("");
                    $("#varBody").empty();
                }
            },
            complete : function(xhr,status){
                //请求完成后最终执行参数
                layer.close(index);
                element.init();
                if(status=='timeout'){//超时,status还有success,error等值的情况
                    ajaxTimeout.abort();
                    // layer.msg("对不起，请求超时，请稍后访问");
                    msgTip("",3);
                }
            }
        });
        
    });
    
    //渲染内容
    function renderProcessList(page,pageSize,sortType,startTime,endTime,name){
        /*说明：此处的page表示当前页*/
        //1.加载ajax流程列表请求
         var index;//用于加载loading的
        sortType = sortType?sortType:"endTime-sort-down";
        name = name?name:"";
        var result = {"pages":"1","page":"1"};
         var ajaxTimeout =$.ajax({
         url:ctx+"/activityFlow/flowFinishList/"+page+"/"+pageSize+"/"+sortType,
         method:"POST",
         data:{"start":startTime,"end":endTime,"flowKey":name},
         dataType:"json",
         async:false,
         timeout:6000,
         beforeSend:function(){
         //请求之前的操作
         index = layer.load(2, {
           shade: [0.5,'#fff'] //0.1透明度的白色背景
         });
         },
         success: function (data) {
             var temp = [];
             if(data.data &&data.data.length>0){
                 //拼接字符串
                 $.each(data.data, function (i,v) {
                     if(!v.businessKey){
                         v.businessKey = "自动启动";
                     }
                  var reason =  v.deleteReason?"<a class='text-danger show-reason' data-content='"+v.deleteReason+"'>错误明细</a>":"正常结束";
                     temp.push('<tr>' +
                         '<td><a class="text-blue show-detail"  pid="'+escapeHtml(v.processInstanceId)+'" title="详情列表">'+ escapeHtml(v.processInstanceId)+'</a></td>' +
                         '<td>'+escapeHtml(v.processDefinitionName)+'</td>' +
                         '<td>'+escapeHtml(v.processDefinitionId)+'</td>' +
                         '<td>'+escapeHtml(v.businessKey)+'</td>' +
                         // '<td>'+escapeHtml(v.startTime)+'</td>' +
                         '<td>'+new Date(escapeHtml(v.startTime)).Format("yyyy-MM-dd hh:mm:ss")+'</td>' +
                         // '<td>'+escapeHtml(v.endTime)+'</td>' +
                         '<td>'+new Date(escapeHtml(v.endTime)).Format("yyyy-MM-dd hh:mm:ss")+'</td>' +
                         '<td>'+reason+'</td>' +
                         '<td><a class="text-blue " lay-filter="varProcess" pid="'+escapeHtml(v.id)+'">参数</a></td>'+
                         '</tr>');
                 });
                 $("#finishedProcessList").empty().append(temp.join(""));
                 $("#finishedProcessPage").show();
                 //分页加载
                 laypage({
                     cont: $(".layui-pagination"),//dom，字符串id,jquery对象都可以
                     pages: data.pages,//总页数
                     curr:data.page,//表示当前页
                     skip: true,//是否展示调整
                     hash:"abc",
                     jump: function(obj, first){
                         if(!first) {
                             //得到了当前页，用于向服务端请求对应数据
                             var curr = obj.curr;
                             //此处用于请求后台，加载数据
                             renderProcessList(curr,pageSize,sortType,startTime,endTime,name);
                         }
                     }
                 });
             }else{
                 $("#finishedProcessPage").hide();
                 $("#finishedProcessList").empty().append('<tr><td class="text-center" colspan="7">暂无数据</td></tr>');
             }

         },
         complete : function(xhr,status){
             //成功后的操作
             layer.close(index);
             element.init();
             if(status=='timeout'){//超时,status还有success,error等值的情况
             ajaxTimeout.abort();
              // layer.msg("对不起，请求超时，请稍后访问");
                 msgTip("",3);
             }
         }
         });
         return result;
    }

    //渲染task列表
    function renderInstanceTaskDetails(page,pageSize,id){
        //ajax请求
        var index;//用于加载loading的
        var url = ctx+"/activityTask/taskListByFlowId/"+id;
        var ajaxtimeout2 =  $.ajax({
            url:url,
            method:"POST",
            data:{},
            cache:false,
            dataType:"json",
            beforeSend: function () {
                //调用之前进行加载
                index = layer.load(2, {
                    shade: [0.5,'#fff'] //0.1透明度的白色背景
                });
            },
            success: function (data) {
                //执行列表加载并处理数据
                var temp = [];

                if(data.data &&data.data.length>0) {
                    //拼接字符串
                    $.each(data.data, function (i, v) {

                        var tmp = '<td></td>';
                        if(v.description){
                            tmp = '<td>' + escapeHtml(v.description) + '</td>';
                        }
                        var da_duetmp = "<td></td>";

                        if(v.startTime){
                            da_duetmp = '<td>'+new Date(escapeHtml(v.startTime)).Format("yyyy-MM-dd hh:mm:ss")+'</td>';
                        }
                        var da_endtmp = "<td></td>";

                        if(v.endTime){
                            da_endtmp = '<td>'+new Date(escapeHtml(v.endTime)).Format("yyyy-MM-dd hh:mm:ss")+'</td>';
                        }
                        temp.push('<tr>' +
                            '<td>' + escapeHtml(v.id) + '</td>' +
                            '<td>' + escapeHtml(v.processInstanceId) + '</td>' +
                            '<td><a  class="" pid="' + escapeHtml(v.id) + '" title="详情列表">' + escapeHtml(v.name) + '</a>' +
                            // '<td>' + escapeHtml(v.createTime) + '</td>' +
                            // '<td>'+new Date(escapeHtml(v.createTime)).Format("yyyy-MM-dd hh:mm:ss")+'</td>' +
                            da_duetmp+da_endtmp+
                            tmp+
                            '</tr>');
                    });
                    $("#taskDetails").empty().append(temp.join(""));
                }else{
                    $("#taskDetails").empty().append('<tr><td class="text-center" colspan="6">暂无数据</td></tr>');
                }

            },
            complete : function(xhr,status){
                //请求完成后最终执行参数
                layer.close(index);
                element.init();
                if(status=='timeout'){//超时,status还有success,error等值的情况
                    ajaxtimeout2.abort();
                    // layer.msg("对不起，请求超时，请稍后访问");
                    msgTip("",3);
                }
            }
        });
    }

    function renderDefList(){
        //ajax请求
        var index;//用于加载loading的
        var url = ctx+"/activityDefine/flowDefAllList";
        var ajaxtimeout2 =  $.ajax({
            url:url,
            method:"POST",
            data:{},
            cache:false,
            dataType:"json",
            beforeSend: function () {
                //调用之前进行加载
                index = layer.load(2, {
                    shade: [0.5,'#fff'] //0.1透明度的白色背景
                });
            },
            success: function (data) {

                if(data &&data) {
                    var str = "";
                    //拼接字符串
                    $.each(data, function (i, v) {

                        // $("#defName").append("<option value='"+v.id+"'>"+v.id+"--"+v.name+"</option>");
                        str += "<option value='"+i+"'>"+i+"--"+v+"</option>";
                    });

                    $("#flowName").append(str);
                    form.render('select');
                }
            },
            complete : function(xhr,status){
                //请求完成后最终执行参数
                //layer.close(index);
                element.init();
                if(status=='timeout'){//超时,status还有success,error等值的情况
                    ajaxtimeout2.abort();
                    // layer.msg("对不起，请求超时，请稍后访问");
                    msgTip("",3);
                }
            }
        });
    }
});
