/**
 * Created by fengyang on 2017/5/19.
 */
layui.use(['form','element','layer','laypage','laydate'], function () {
    var element = layui.element(), layer = layui.layer,$ = layui.jquery,laypage = layui.laypage,laydate = layui.laydate,form=layui.form();
    var layerHeight =$(window).height(); //计算弹框高度使用
    var layerWidth = $(window).width();//计算弹框宽度使用
    //时间筛选
    var start = {
        istoday: false,
        choose: function(datas){
            end.min = datas; //开始日选好后，重置结束日的最小日期
            end.start = datas //将结束日的初始值设定为开始日
        }
    };
    var end = {
        istoday: false,
        choose: function(datas){
            start.max = datas; //结束日选好后，重置开始日的最大日期
        }
    };
    //开始时间事件
    $(document).on("click","#startTime",function () {
        start.elem = this;
        laydate(start);
    });
    //结束时间事件
    $(document).on("click","#endTime",function () {
        end.elem = this;
        laydate(end);
    });
    renderDefList();
    //页面初始化加载默认第一页
    rendeInstances(1,8,"id-sort-down",$("#startTime").val(),$("#endTime").val(),$("#flowName").val());

    var id;//定义的id参数
    //流程实例搜索事件
    //排序事件
    $(document).on("click",".main-sort",function () {
        //刷新列表
        var sortType =  $(".main-sort:visible").attr("data-attr");//获取排序的名称
        rendeInstances(1,8,sortType,$("#startTime").val(),$("#endTime").val(),$("#flowName").val());
        $(this).siblings().show();
        $(this).hide();
    });
    //流程实例搜索事件
    $(document).on("click","#searchInstanceList",function () {
        var sortType =  $(".main-sort:visible").attr("data-attr");//获取排序的名称

        rendeInstances(1,8,sortType,$("#startTime").val(),$("#endTime").val(),$("#flowName").val());
    });

    //查看流程节点
    $(document).on("click","a[lay-filter=showProcess]",function () {
        var height = parseInt(layerHeight*0.88);
        var width = parseInt(layerWidth*0.74);
        if(layerHeight<400){
            parseInt(layerHeight*0.85);
        }
        if(layerWidth<1000){
            width = parseInt(layerWidth*0.65);
        }
        var showFlowIndex=layer.open({
            type:1,
            offset:"10px",
            title:"流程节点详情",
            skin: 'layui-layer-molv',
            content:$("#showFlowWin"),
            area: [width+'px', height+'px'],
            btnAlign: 'r',
            btn:['关闭'],
            yes:function(){
                layer.close(showFlowIndex);
            }
        });
        $("#flowFrame").css({"width":$(".layui-layer-content").width()-40,"height":$(".layui-layer-content").height()-40}).attr("src",$(this).attr("data-url"));
    });

    //删除流程节点
    $(document).on("click","a[lay-filter=delProcess]",function () {
        if(!$(this).hasClass("disabled")){
            $("#delId").val($(this).attr("pid"));
            var showFlowIndex=layer.open({
                type:1,
                offset:"c",
                title:"删除实例",
                skin: 'layui-layer-molv',
                content:$("#delProcessWin"),
                area: ['530px', 'auto']
            });
        }
    });
    //启动参数

    $(document).on("click","a[lay-filter=varProcess]",function () {
        var url = ctx+"/activityFlow/varByFlowId/"+$(this).attr("pid");
        var index;
        var ajaxTimeout =$.ajax({
            url:url,
            method:"POST",
            data:{},
            dataType:"json",
            async:false,
            timeout:6000,
            beforeSend:function(){
                //请求之前的操作
                index = layer.load(2, {
                    shade: [0.5,'#fff'] //0.1透明度的白色背景
                });
            },
            success: function (data) {
                //成功后的操作
                if(data){
                    var temp = [];
                    //拼接字符串
                    $("#jobDate").html(data["jobDate"]);
                    $.each(data["retryMap"], function (i,v) {
                        temp.push('<tr>' +
                            '<td>'+i+'</td>'+
                            '<td>'+v+'</td>'+
                            '</tr>');
                    });
                    if(temp.length>0) {
                        $("#varBody").empty().append(temp.join(""));
                    }else{
                        $("#varBody").empty().append('<tr><td class="text-center" colspan="3">无参数</td></tr>');
                    }
                }else{
                    $("#jobDate").html("");
                    $("#varBody").empty();
                }
                var height = parseInt(layerHeight*0.60);
                var width = parseInt(layerWidth*0.40);
                var showflowVarIndex=layer.open({
                    type:1,
                    offset:"c",
                    title:"启动参数详情",
                    skin: 'layui-layer-molv',
                    content:$("#flowVarWin"),
                    area: [width+'px', height+'px'],
                    btn: ['关闭'],
                    yes:function () {
                        layer.close(showflowVarIndex);
                    }
                });

            },
            complete : function(xhr,status){
                //请求完成后最终执行参数
                layer.close(index);
                element.init();
                if(status=='timeout'){//超时,status还有success,error等值的情况
                    ajaxTimeout.abort();
                    // layer.msg("对不起，请求超时，请稍后访问");
                    msgTip("",3);
                }
            }
        });

        // var showflowVarIndex=layer.open({
        //     type:1,
        //     offset:"c",
        //     title:"启动参数详情",
        //     skin: 'layui-layer-molv',
        //     content:$("#flowVarWin"),
        //     area: ['530', 'auto']
        // });
    });

    form.on("submit(confirmDelProcess)",function (data) {
        var reason = $("#roleDesc").val().trim();
        $.ajax({
            url:ctx+"/activityFlow/deleteFlow/"+$("#delId").val(),
            method:"post",
            data:{"reason":reason},
            cache:false,
            dataType:"json",
            success: function (data) {
               location.reload();
            },
            complete:function () {
                //调用完成之后的加载
            }
        })
    });

    //点击事件
    $(document).on("click",".show-detail", function () {
        $(".instance-list").hide();
        $(".instance-detail-list").show();
        id = $(this).attr("pid");
        $(".migu-tab li.layui-this").trigger("click");
    });
    $(document).on("click",".return-list", function () {
        $(".instance-list").show();
        $(".instance-detail-list").hide();
    });
    $(document).on("click",".flowStatus", function () {//挂起
        if(!$(this).hasClass("disabled")){
            flowUpdate($(this).attr("pid"),$(this).attr("status"),$(this).attr("id"));
        }
    });
    $(document).on("click",".retryTask", function () {//重新任务
        retryTask($(this).attr("pid"));
    });
    $(document).on("click",".retryJob", function () {//重新工作
        retryJob($(this).attr("pid"));
    });

    //tab点击事件
    $(".migu-tab li").on("click",function () {
        var dataUrl = $(this).attr("data-url");
        if(dataUrl=="1"){
            //调用task的接口
            renderInstanceTaskDetails(1,8,id);

        }else if(dataUrl=="2"){
            //调用job的接口
            renderInstanceJobDetails(1,8,id);

        }
    });


    //渲染内容
    function rendeInstances(page,pageSize,sortType,startTime,endTime,flowKey){
        /*说明：此处的page表示当前页*/
        //1.加载ajax流程列表请求
        var index;//用于加载loading的
        sortType  = sortType?sortType:"id-sort-down";
        startTime  = startTime?startTime:"";
        endTime  = endTime?endTime:"";
        flowKey  = flowKey?flowKey:"";
        var url = ctx+"/activityFlow/flowList/"+page+"/"+pageSize+"/"+sortType;
         var ajaxTimeout =$.ajax({
         url:url,
         method:"POST",
         data:{"start":startTime,"end":endTime,"flowKey":flowKey},
         dataType:"json",
         async:false,
         timeout:6000,
         beforeSend:function(){
            //请求之前的操作
           index = layer.load(2, {
           shade: [0.5,'#fff'] //0.1透明度的白色背景
         });
         },
         success: function (data) {
            //console.log(data);
         //成功后的操作
             var temp = [];
             if(data.data &&data.data.length>0){
                 //删除权限
                 var deleteFlowDisable ="";
                 if($.trim($("#authList .instance-deleteFlow").html())!="true"){
                     //没有权限
                     deleteFlowDisable ="disabled";
                 }
                 //挂起激活权限
                 var instanceUpdateDisable ="";
                 if($.trim($("#authList .instance-instanceUpdate").html())!="true"){
                     //没有权限
                     instanceUpdateDisable ="disabled";
                 }

                 //拼接字符串
                 $.each(data.data, function (i,v) {

                     var tmp = '<a class="flowStatus text-blue '+instanceUpdateDisable+'"   pid="'+escapeHtml(v.id)+'" status="suspend" id="flow'+escapeHtml(v.id)+'">挂起</a>';
                     if(v.suspensionState==2){//挂起状态
                        tmp = '<a class="flowStatus text-blue '+instanceUpdateDisable+' "   pid="'+escapeHtml(v.id)+'" status="active" id="flow'+escapeHtml(v.id)+'">激活</a>';
                     }
                     if(!v.businessKey){
                         v.businessKey = "自动启动";
                     }
                     temp.push('<tr>' +
                         '<td><a class="text-blue show-detail"  pid="'+escapeHtml(v.processInstanceId)+'" title="详情列表">'+escapeHtml(v.processInstanceId)+'</a></td>' +
                         '<td>'+escapeHtml(v.processDefinitionName)+'</td>'+
                         '<td>'+escapeHtml(v.processDefinitionId)+'</td>'+
                         '<td>'+escapeHtml(v.businessKey)+'</td>'+
                         '<td>'+new Date(escapeHtml(v.startTime)).Format("yyyy-MM-dd hh:mm:ss")+'</td>' +
                         // '<td>'+escapeHtml(v.startTime)+'</td>' +
                         '<td>'+tmp+'　|　 <a class="text-blue" id="'+escapeHtml(v.id)+'" lay-filter="showProcess" title="点击查看流程图" data-url="'+ctx+'/activityDisplay/toDis?defId='+escapeHtml(v.processDefinitionId)+'&insId='+escapeHtml(v.id)+'" >查看节点</a>' +
                         '<a class="text-blue '+deleteFlowDisable+'" lay-filter="delProcess" pid="'+escapeHtml(v.id)+'">　|　 删除</a>' +
                         '<a class="text-blue " lay-filter="varProcess" pid="'+escapeHtml(v.id)+'">　|　 参数</a></td>'+
                         '</tr>');
                 });
                 $("#instances").empty().append(temp.join(""));
                 //分页加载
                 $("#instancePage").show();
                 laypage({
                     cont: $(".layui-pagination"),//dom，字符串id,jquery对象都可以
                     pages: data.pages,//总页数
                     curr:data.page,//表示当前页
                     skip: true,//是否展示调整
                     hash:"abc",
                     jump: function(obj, first){
                         if(!first){
                             //得到了当前页，用于向服务端请求对应数据
                             var curr = obj.curr;
                             //此处用于请求后台，加载数据
                             rendeInstances(curr,pageSize,sortType,startTime,endTime,flowKey);
                         }

                     }
                 });
             }else{
                 $("#instancePage").hide();
                 $("#instances").empty().append('<tr><td class="text-center" colspan="6">暂无数据</td></tr>');
             }

         },
         complete : function(xhr,status){
             //请求完成后最终执行参数
             layer.close(index);
             element.init();
             if(status=='timeout'){//超时,status还有success,error等值的情况
             ajaxTimeout.abort();
              // layer.msg("对不起，请求超时，请稍后访问");
                 msgTip("",3);
             }
         }
         });
    }
    //渲染task列表
    function renderInstanceTaskDetails(page,pageSize,id){
        //ajax请求
        var index;//用于加载loading的
        var url = ctx+"/activityTask/taskListByFlowId/"+id;
        var ajaxtimeout2 =  $.ajax({
            url:url,
            method:"POST",
            data:{},
            cache:false,
            dataType:"json",
            beforeSend: function () {
                //调用之前进行加载
                index = layer.load(2, {
                    shade: [0.5,'#fff'] //0.1透明度的白色背景
                });
            },
            success: function (data) {
                //执行列表加载并处理数据
                var temp = [];

                if(data.data &&data.data.length>0) {
                    //拼接字符串
                    $.each(data.data, function (i, v) {

                        var tmp = '<td></td>';
                        var tmp_retry = '<td></td>';
                        if(v.description){
                            tmp = '<td>' + escapeHtml(v.description) + '</td>';
                        }
                        var da_duetmp = "";

                        if(v.startTime){
                            da_duetmp = '<td>'+new Date(escapeHtml(v.startTime)).Format("yyyy-MM-dd hh:mm:ss")+'</td>';
                        }else{
                            da_duetmp = "<td></td>";
                        }
                        var da_endtmp = "<td></td>";

                        if(v.endTime){
                            da_endtmp = '<td>'+new Date(escapeHtml(v.endTime)).Format("yyyy-MM-dd hh:mm:ss")+'</td>';
                        }else{
                            if(v.description){
                                tmp_retry = '<td><a class="retryTask text-blue" pid="'+escapeHtml(v.id)+'" id="taskId'+escapeHtml(v.id)+'">重新执行</a></td>';
                            }
                        }
                        temp.push('<tr>' +
                            '<td>' + escapeHtml(v.id) + '</td>' +
                            '<td>' + escapeHtml(v.processInstanceId) + '</td>' +
                            '<td><a  class="" pid="' + escapeHtml(v.id) + '" title="详情列表">' + escapeHtml(v.name) + '</a>' +
                            // '<td>' + escapeHtml(v.createTime) + '</td>' +
                            // '<td>'+new Date(escapeHtml(v.createTime)).Format("yyyy-MM-dd hh:mm:ss")+'</td>' +
                            da_duetmp+da_endtmp+
                                tmp+ tmp_retry +
                            '</tr>');
                    });
                    $("#instanceTaskDetails").empty().append(temp.join(""));
                }else{
                    $("#instanceTaskDetails").empty().append('<tr><td class="text-center" colspan="7">暂无数据</td></tr>');
                }

            },
            complete : function(xhr,status){
                //请求完成后最终执行参数
                layer.close(index);
                element.init();
                if(status=='timeout'){//超时,status还有success,error等值的情况
                    ajaxtimeout2.abort();
                   // layer.msg("对不起，请求超时，请稍后访问");
                    msgTip("",3);
                }

            }


        });
    }
    //渲染job列表
    function renderInstanceJobDetails(page,pageSize,id){
        var index;
        var phoneUrl = ctx+"/activityJob/jobList/"+id+"/"+page+"/"+pageSize;
        var ajaxTimeout3 = $.ajax({
            url:phoneUrl,
            method:'POST',
            data:{},
            dataType:"json",
            async:false,
            timeout:6000,
            beforeSend:function () {
                index = layer.load(2, {
                    shade: [0.5,'#000'] //0.1透明度的白色背景
                });
            },
            success:function (data) {
                var temp = [];

                if(data.data &&data.data.length>0){
                    //拼接字符串
                    $.each(data.data, function (i,v) {
                        var da_duetmp = "";
                        var da_config = "";
                        var da_retry = "<td></td>";
                        if(v.dueDate){
                            da_duetmp = '<td>'+new Date(escapeHtml(v.dueDate)).Format("yyyy-MM-dd hh:mm:ss")+'</td>';
                        }else{
                            da_duetmp = "<td></td>";
                        }
                        if(v.exceptionMessage){
                            da_config = '<td>'+escapeHtml(v.exceptionMessage)+'</td>';
                        }else{
                            da_config = "<td></td>";
                        }
                        if(v.exceptionMessage){
                            da_retry = '<td><a class="text-blue retryJob" pid="'+escapeHtml(v.id)+'" id="jobId'+escapeHtml(v.id)+'">重新执行</a></td>';
                        }
                        temp.push('<tr>' +
                            '<td>'+ escapeHtml(v.id)+'</td>' +
                            '<td>' + escapeHtml(v.processInstanceId) + '</td>' + da_duetmp + da_config +
                            // '<td>'+new Date(escapeHtml(v.duedate)).Format("yyyy-MM-dd hh:mm:ss")+'</td>' +
                            // '<td>'+escapeHtml(v.duedate)+'</td>' +
                            // '<td>'+escapeHtml(v.jobHandlerConfiguration)+'</td>' +
                            // '<td><a class="text-blue retryJob" pid="'+escapeHtml(v.id)+'" id="jobId'+escapeHtml(v.id)+'">重新执行</a></td>' +
                            da_retry+
                            '</tr>');
                    });
                    $("#instanceJobDetails").empty().append(temp.join(""));
                    element.init();
                }else{
                    $("#instanceJobDetails").empty().append('<tr><td class="text-center" colspan="5">暂无数据</td></tr>');
                }
            },
            complete : function(XMLHttpRequest,status){ //请求完成后最终执行参数
                if(status=='timeout'){//超时,status还有success,error等值的情况
                    ajaxTimeout3.abort();
                    //layer.msg("对不起，请求超时，请稍后访问");
                    msgTip("",3);
                }
                layer.close(index);
            }

        });
    }

    function flowUpdate(flowId,flowStatus,aId){
        var index;
        var phoneUrl = ctx+"/activityFlow/instanceUpdate/"+flowStatus+"/"+flowId;
        var ajaxTimeout3 = $.ajax({
            url:phoneUrl,
            method:'POST',
            data:{},
            dataType:"json",
            async:false,
            timeout:6000,
            beforeSend:function () {
                index = layer.load(2, {
                    shade: [0.5,'#000'] //0.1透明度的白色背景
                });
            },
            success:function (data) {
                if(data.data &&data.data.length>0){
                    //layer.msg(data.msg);
                    if(data.status=="0"){
                        //操作失败
                        msgTip(data.msg,data.status);
                    }else if(data.status=="1"){
                        //表示操作成功,不提示消息内容
                        msgTip(data.msg,data.status,false,true);
                    }
                    var tmp = "suspend";
                    var tmsg = "挂起";
                    if(flowStatus=="suspend"){
                        tmp = "active";
                        tmsg = "激活";
                    }
                    $("#"+aId).text(tmsg);
                    $("#"+aId).attr("status",tmp);
                }
            },
            complete : function(XMLHttpRequest,status){ //请求完成后最终执行参数
                if(status=='timeout'){//超时,status还有success,error等值的情况
                    ajaxTimeout3.abort();
                    //layer.msg("对不起，请求超时，请稍后访问");
                    msgTip("",3);
                }
                layer.close(index);
            }

        });

    }

    function retryTask(taskId){
        var index;
        var phoneUrl = ctx+"/activityTask/retryTask/"+taskId;
        var ajaxTimeout3 = $.ajax({
            url:phoneUrl,
            method:'POST',
            data:{},
            dataType:"json",
            async:false,
            timeout:6000,
            beforeSend:function () {
                index = layer.load(2, {
                    shade: [0.5,'#000'] //0.1透明度的白色背景
                });
            },
            success:function (data) {
                // layer.msg(data.data);
                if(data.status=="0"){
                    //操作失败
                    msgTip(data.msg,data.status);
                }else if(data.status=="1"){
                    //表示操作成功,不提示消息内容
                    msgTip(data.msg,data.status);
                }
                $("#taskId"+taskId).text("");
            },
            complete : function(XMLHttpRequest,status){ //请求完成后最终执行参数
                if(status=='timeout'){//超时,status还有success,error等值的情况
                    ajaxTimeout3.abort();
                    //layer.msg("对不起，请求超时，请稍后访问");
                    msgTip("",3);
                }
                layer.close(index);
            }
        });
    }

    function retryJob(jobId){
        var index;
        var phoneUrl = ctx+"/activityJob/retryJob/"+jobId;
        var ajaxTimeout3 = $.ajax({
            url:phoneUrl,
            method:'POST',
            data:{},
            dataType:"json",
            async:false,
            timeout:6000,
            beforeSend:function () {
                index = layer.load(2, {
                    shade: [0.5,'#000'] //0.1透明度的白色背景
                });
            },
            success:function (data) {
                if(data.data &&data.data.length>0){
                    // layer.msg(data.data);
                    if(data.status=="0"){
                        //操作失败
                        msgTip(data.msg,data.status);
                    }else if(data.status=="1"){
                        //表示操作成功,不提示消息内容
                        msgTip(data.msg,data.status);
                    }
                    $("#jobId"+jobId).text("");
                }
            },
            complete : function(XMLHttpRequest,status){ //请求完成后最终执行参数
                if(status=='timeout'){//超时,status还有success,error等值的情况
                    ajaxTimeout3.abort();
                   // layer.msg("对不起，请求超时，请稍后访问");
                    msgTip("",3);
                }
                layer.close(index);
            }

        });
    }
    //自定义验证规则
    form.verify({
        len:function (value,item) {
            //限制textarea长度
            if(value && !/d{0,100}/g.test(value)){
                return 'url不能超过100个字符';
            }
        },
        filterChar:function (value,item) {
            if(!new RegExp("^[a-zA-Z0-9_\u4e00-\u9fa5\\s·]+$").test(value)){
                return '输入内容不能包含特殊字符';
            }
        }

    });
    function renderDefList(){
        //ajax请求
        var index;//用于加载loading的
        var url = ctx+"/activityDefine/flowDefAllList";
        var ajaxtimeout2 =  $.ajax({
            url:url,
            method:"POST",
            data:{},
            cache:false,
            dataType:"json",
            beforeSend: function () {
                //调用之前进行加载
                index = layer.load(2, {
                    shade: [0.5,'#fff'] //0.1透明度的白色背景
                });
            },
            success: function (data) {

                if(data) {
                    var str = "";
                    //拼接字符串
                    $.each(data, function (i, v) {

                        // $("#defName").append("<option value='"+v.id+"'>"+v.id+"--"+v.name+"</option>");
                        str += "<option value='"+i+"'>"+i+"--"+v+"</option>";
                    });

                    $("#flowName").append(str);
                    form.render('select');
                }
            },
            complete : function(xhr,status){
                //请求完成后最终执行参数
                //layer.close(index);
                element.init();
                if(status=='timeout'){//超时,status还有success,error等值的情况
                    ajaxtimeout2.abort();
                    // layer.msg("对不起，请求超时，请稍后访问");
                    msgTip("",3);
                }
            }
        });
    }
});
