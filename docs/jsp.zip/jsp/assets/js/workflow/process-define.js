/**
 * Created by fengyang on 2017/5/18.
 */
layui.use(['form','element','layer','laypage','laydate'], function () {
    var time_fmt = "time";
    var element = layui.element(), form = layui.form(),layer = layui.layer,$ = layui.jquery,laypage = layui.laypage,laydate = layui.laydate;
    var layerHeight =$(window).height(); //计算弹框高度使用
    var layerWidth = $(window).width();//计算弹框宽度使用
    //时间筛选
    var start = {
        istoday: false,
        choose: function(datas){
            end.min = datas; //开始日选好后，重置结束日的最小日期
            end.start = datas; //将结束日的初始值设定为开始日
        }
    };
    var end = {
        istoday: false,
        choose: function(datas){
            start.max = datas; //结束日选好后，重置开始日的最大日期
        }
    };
    //开始时间事件
    $(document).on("click","#startTime",function () {
        start.elem = this;
        laydate(start);
    });
    //结束时间事件
    $(document).on("click","#endTime",function () {
        end.elem = this;
        laydate(end);
    });

    //启动时间选择
    var starTime = {
        event: 'click', //触发事件
        //min: laydate.now(),
        format: 'YYYY-MM-DD hh:mm:ss', //日期格式
        istime: true, //是否开启时间选择
        isclear: true, //是否显示清空
        istoday: true, //是否显示今天
        issure: true, //是否显示确认
        choose: function(datas){
            $("#startDate").attr("data-time",datas);
        }
    };
    $(document).on("click","#startDate",function () {
        starTime.elem = this;
        laydate(starTime);
    });

    //页面初始化加载默认第一页
    var defName = $("#defName").val();//流程定义的名称
    renderDefinitions(1,8,"id-sort-down",defName);

    var id;//定义的id参数
    //排序事件
    $(document).on("click",".main-sort",function () {
        //刷新列表
        var sortType =  $(this).attr("data-attr");//获取排序的名称
        renderDefinitions(1,8,sortType,$("#defName").val());
        $(this).siblings().show();
        $(this).hide();
    });
    //流程定义搜索事件
   $(document).on("click","#searchDefineList",function () {
       var sortType =  $(".main-sort:visible").attr("data-attr");//获取排序的名称
       $("#defName").val($("#defName").val().trim());
       renderDefinitions(1,8,sortType,$("#defName").val());
   });
    $("#defName").on("keyup",function (event) {
        if(event.keyCode==13){
            var sortType =  $(".main-sort:visible").attr("data-attr");//获取排序的名称
            $("#defName").val($("#defName").val().trim());
            renderDefinitions(1,8,sortType,$("#defName").val());
        }
    });

    $(document).on("click",".flowStatus", function () {//挂起
        flowUpdate($(this).attr("pid"),$(this).attr("status"),$(this).attr("id"));
    });

    //进入详情点击事件
    $(document).on("click",".show-detail", function () {
        $(".define-list").hide();
        $(".define-detail-list").show();
        id = $(this).attr("pid");
        $(".migu-tab li.layui-this").trigger("click");
    });
    //返回上一级点击事件
    $(document).on("click",".return-list", function () {
        $(".define-list").show();
        $(".define-detail-list").hide();
    });
    //启动流程事件
    $(document).on("click",".start-process", function () {
        //加载流程列表
        var defId = $(this).attr("pid");
        // var keyId = $(this).attr("kid");
        showStartFlowList(defId);
        //弹出框
        var height = parseInt(layerHeight*0.75);
        if(height<400){
            height = parseInt(layerHeight*0.70);
        }
        var width = parseInt(layerWidth*0.52);
        if(layerWidth<1000){
            width = parseInt(layerWidth*0.45);
        }
        var startFlowIndex=layer.open({
            type:1,
            title:"启动流程",
            offset:"15px",
            skin: 'layui-layer-molv',
            content:$("#startFlowWin"),
            area: [width+'px', height+'px'],
            btnAlign: 'l',
            btn:['确定','取消'],
            yes:function () {
                //确定按钮的回调,ajax调用
                var taskInfo = "";
                var dom = $("#startFlowWin").find("table tbody").find("input[name=checkbox]:checked");//获取当前选中的checkbox
                var flag = false;
                if(!$("#startDate").val()){
                   layer.msg("请选择时间");
                    $("#startDate").focus();
                    return false;
                }
                if(dom.length>0){
                    $.each(dom,function (i,v) {
                        var splitChar = "";//分隔符
                        if(!flag){
                            splitChar = (i==dom.length-1)?"":",";
                            taskInfo +=$(this).attr("data-id")+splitChar;
                        }
                    });
                    $.ajax({
                        url: ctx + "/activityFlow/startFlow/" + defId,
                        method: "POST",
                        data: {"taskInfo": taskInfo, "time": $("#startDate").val(), "timeFmt": time_fmt},
                        dataType: "json",
                        beforeSend: function () {
                            layer.close(startFlowIndex);
                        },
                        success: function (data) {
                            // layer.msg(data.msg);
                            //提示内容修改
                            if (data.status == "0") {
                                //操作失败
                                msgTip(data.msg, data.status);
                            } else if (data.status == "1") {
                                //表示操作成功,不提示消息内容
                                msgTip(data.msg, data.status);
                            }
                        },
                        complete: function () {
                            element.init();
                            $("#startFlowForm")[0].reset();//jquery原生的重置表单
                            time_fmt = "time";
                        }
                    });
                }else{
                    layer.msg("请至少选择一个任务");
                }
            },
            btn2:function () {
              //取消按钮操作
                $("#startFlowForm")[0].reset();//jquery原生的重置表单
                time_fmt = "time";
           }
        });
        form.render('radio');

        // var defId = $(this).attr("pid");
        // startFlow(defId);
    });


    //日、月、时间点点击事件
    form.on('radio(dateformat)',function (elem) {
        var formatValue = elem.value;//value值
        if(formatValue=="time"){
            //日期格式展示默认的
            $("#startDate").val($("#startDate").attr("data-time"));
            time_fmt = "time";
        }else if(formatValue=="day"){
            time_fmt = "day";
            $("#startDate").val($("#startDate").attr("data-time").substr(0,10));
        }else if(formatValue=="month"){
            time_fmt = "month";
            $("#startDate").val($("#startDate").attr("data-time").substr(0,7));
        }
        if($("#startDate").val()){
        }else{
            layer.msg("请选择时间");
            $("#startDate").focus();
        }

    });
    //转换为MODEL
    $(document).on("click",".convert-process", function () {
        var defId = $(this).attr("pid");
        convertFlow(defId);
    });

    //tab点击事件
    $(".migu-tab li").on("click",function () {
        var startTime = $("#startTime").val();
        var endTime = $("#endTime").val();
        var dataUrl = $(this).attr("data-url");
        if(dataUrl=="1"){
          renderFlowListDetails(1,8,id,startTime,endTime);
        }
    });

    //详情搜索功能
    form.on("submit(searchDefineDetailList)",function (data) {
        //往后台传递数据查询，按时间搜索
        var startTime = $("#startTime").val();
        var endTime = $("#endTime").val();
        renderFlowListDetails(1,8,id,startTime,endTime);
        return false;
    });
    //详情排序事件
    $(document).on("click",".detail-sort",function () {
        //刷新列表
        var startTime = $("#startTime").val();
        var endTime = $("#endTime").val();
        var sortType =  $(this).attr("data-attr");//获取排序的名称
        renderFlowListDetails(1,8,id,startTime,endTime,sortType);
        $(this).siblings().show();
        $(this).hide();
    });
    //复选框全选
    form.on('checkbox(allChoose)', function(data){
        var child = $(data.elem).parents('table').find('tbody input[type="checkbox"]');
        child.each(function(index, item){
            item.checked = data.elem.checked;
        });
        form.render('checkbox');
    });

    //查看流程图
    $(document).on("click","button[lay-filter=showProcess]",function () {
        var height = parseInt(layerHeight*0.88);
        var width = parseInt(layerWidth*0.74);
        if(layerHeight<400){
            parseInt(layerHeight*0.85);
        }
        if(layerWidth<1000){
            width = parseInt(layerWidth*0.65);
        }
        var showFlowIndex=layer.open({
            type:1,
            offset:"10px",
            title:"流程图详情",
            skin: 'layui-layer-molv',
            content:$("#showFlowWin"),
            area: [width+'px', height+'px'],
            btnAlign: 'r',
            btn:['关闭'],
            yes:function(){
                layer.close(showFlowIndex);
            }
        });
        $("#flowFrame").css({"width":$(".layui-layer-content").width()-40,"height":$(".layui-layer-content").height()-40}).attr("src",$(this).attr("data-url"));
    });

    //查看节点点击事件
    $(document).on("click",".showInstanceProcess",function () {
        var height = parseInt(layerHeight*0.88);
        var width = parseInt(layerWidth*0.74);
        if(layerHeight<400){
            parseInt(layerHeight*0.85);
        }
        if(layerWidth<1000){
            width = parseInt(layerWidth*0.65);
        }
        var showTaskFlowIndex=layer.open({
            type:1,
            offset:"10",
            title:"流程节点详情",
            skin: 'layui-layer-molv',
            content:$("#showTaskFlowWin"),
            area: [width+'px', height+'px'],
            btnAlign: 'r',
            btn:['关闭'],
            yes:function(){
                layer.close(showTaskFlowIndex);
            }
        });
        $("#flowNodeFrame").css({"width":$(".layui-layer-content").width()-40,"height":$(".layui-layer-content").height()-40}).attr("src",$(this).attr("data-url"));
    });

    //渲染内容列表
    function renderDefinitions(page,pageSize,sortType,defName){
        /*说明：此处的page表示当前页,pageSize表示一页展示几条数据，defName:表示流程定义的名称 ，sortType表示排序类型*/
        //1.加载ajax流程列表请求
        var index;//用于加载loading的
        sortType  = sortType?sortType:"id-sort-down";
         var ajaxTimeout =$.ajax({
         url:ctx+"/activityDefine/flowDefList/"+page+"/"+pageSize+"/"+sortType,
         method:"POST",
         data:{"searchName":defName},
         dataType:"json",
         async:false,
         timeout:6000,
         beforeSend:function(){
         //请求之前的操作
         index = layer.load(2, {
         shade: [0.5,'#fff'] //0.1透明度的白色背景
         });
         },
         success: function (data) {
             var temp = [];
             if(data.data &&data.data.length>0){
                 //启动权限
                 var startFlowDisable ="";
                 if($.trim($("#authList .define-startFlow").html())!="true"){
                     //没有权限
                     startFlowDisable = disabled="disabled";
                 }
                 //转为model权限
                 var convertModelDisable ="";
                 if($.trim($("#authList .define-convertModel").html())!="true"){
                     //没有权限
                     convertModelDisable = disabled="disabled";
                 }
                 //挂起激活权限
                 var defUpdateDisable ="";
                 if($.trim($("#authList .define-defUpdate").html())!="true"){
                     //没有权限
                     defUpdateDisable = disabled="disabled";
                 }

                 //拼接字符串
                 $.each(data.data, function (i,v) {
                     var tmp = '<button class="layui-btn layui-btn-small flowStatus" '+defUpdateDisable+' pid="'+escapeHtml(v.id)+'" status="suspend" id="flow'+i+'">挂起</button>';
                     if(v.suspensionState==2){//挂起状态
                         tmp = '<button class="layui-btn layui-btn-small flowStatus"  '+defUpdateDisable+'  pid="'+escapeHtml(v.id)+'" status="active" id="flow'+i+'">激活</button>';
                     }

                     temp.push('<tr>' +
                         '<td>'+ escapeHtml(v.id)+'</td>' +
                         '<td><a class="text-blue show-detail"  pid="'+escapeHtml(v.id)+'" title="详情列表">'+escapeHtml(v.name)+'</a></td>'+
                         '<td>'+escapeHtml(v.version)+'</td>' +
                         '<td>'+escapeHtml(v.key)+'</td>' +
                         '<td>'+escapeHtml(v.repeat)+'</td>' +
                         '<td>' +//onclick="startFlow(\''+escapeHtml(v.id)+'\')"
                         '<button class="layui-btn layui-btn-small layui-btn-normal start-process" '+startFlowDisable+'  pid="'+escapeHtml(v.id)+'" ><i class="layui-icon">&#xe623;</i>启动</button>' + //kid="'+escapeHtml(v.key)+'"
                         '<button class="layui-btn layui-btn-small layui-btn-warm "  data-url="'+ctx+'/activityDisplay/toDis?defId='+escapeHtml(v.id)+'" lay-filter="showProcess"><i class="layui-icon">&#xe64a;</i>查看流程图</button>' +
                         '<button class="layui-btn layui-btn-small layui-btn-danger  convert-process"  '+convertModelDisable+' pid="'+escapeHtml(v.id)+'">转为MODEL</button>' +
                             tmp+
                         '</td>' +
                         '</tr>');
                 });
                 $("#definitions").empty().append(temp.join(""));
                 //列表分页加载
                 $("#definePage").show();
                 laypage({
                     cont: $("#definePage"),//dom，字符串id,jquery对象都可以
                     pages: data.pages,//总页数
                     curr:data.page,//表示当前页
                     skip: true,//是否展示调整
                     hash:"abc",
                     jump: function(obj, first){
                         if(!first){
                             //得到了当前页，用于向服务端请求对应数据
                             var curr = obj.curr;
                             //此处用于请求后台，加载数据
                             renderDefinitions(curr,pageSize,sortType,defName);
                         }
                     }
                 });
             }else{
                 $("#definePage").hide();
                 $("#definitions").empty().append('<tr><td class="text-center" colspan="6">暂无数据</td></tr>');
             }
         },
         complete : function(xhr,status){
             //请求完成后最终执行参数
             layer.close(index);
             element.init();
             if(status=='timeout'){//超时,status还有success,error等值的情况
             ajaxTimeout.abort();
              //layer.msg("对不起，请求超时，请稍后访问");
                 msgTip("",3);
            }

         }
      });
    }
    // //启动流程实例
    // function startFlow(defId){
    //     var index;//用于加载loading的
    //     var ajaxTimeout =$.ajax({
    //         url:ctx+"/activityFlow/start/"+defId,
    //         method:"post",
    //         data:{},
    //         dataType:"json",
    //         async:false,
    //         timeout:6000,
    //         beforeSend:function(){
    //             //请求之前的操作
    //             index = layer.load(2, {
    //                 shade: [0.5,'#fff'] //0.1透明度的白色背景
    //             });
    //         },
    //         success: function (data) {
    //             //成功后的操作
    //            console.log(data);
    //            alert(data);
    //             //提示内容修改
    //             if(data.status=="0"){
    //                 //操作失败
    //                 msgTip(data.msg,data.status);
    //             }else if(data.status=="1"){
    //                 //表示操作成功,不提示消息内容
    //                 msgTip(data.msg,data.status);
    //             }
    //         },
    //         error: function (xhr,error,status) {
    //             //layer.msg("对不起，请求访问失败，请稍后操作！");
    //             msgTip("",2);
    //         },
    //         complete : function(xhr,status){ //请求完成后最终执行参数
    //             if(status=='timeout'){//超时,status还有success,error等值的情况
    //                 ajaxTimeout.abort();
    //                 //layer.msg("对不起，请求超时，请稍后访问");
    //                 msgTip("",3);
    //             }
    //             layer.close(index);
    //         }
    //     });
    //
    // }
    //渲染task列表
    function renderFlowListDetails(page,pageSize,id,startTime,endTime,sortType){
        //ajax请求
        var index;//用于加载loading的
        sortType = sortType?sortType:"id-sort-down";
         var ajaxTimeout =$.ajax({
         url:ctx+"/activityFlow/flowListByDef/"+id+"/"+page+"/"+pageSize+"/"+sortType,
         method:"",
         data:{"start":startTime,"end":endTime},
         dataType:"json",
         async:false,
         timeout:6000,
         beforeSend:function(){
             //请求之前的操作
             index = layer.load(2, {
              shade: [0.5,'#fff'] //0.1透明度的白色背景
             });
         },
         success: function (data) {
             //加载请求
             var temp = [];
             if(data.data &&data.data.length>0){
                 //拼接字符串
                 $.each(data.data, function (i,v) {
                     temp.push('<tr>' +
                         '<td>'+escapeHtml(v.processInstanceId)+'</td>' +
                         '<td>'+escapeHtml(v.processDefinitionId)+'</td>'+
                         // '<td>'+escapeHtml(v.startTime)+'</td>' +
                         '<td>'+new Date(escapeHtml(v.startTime)).Format("yyyy-MM-dd hh:mm:ss")+'</td>' +
                         '<td><a class="text-blue showInstanceProcess" id="'+escapeHtml(v.id)+'" title="点击查看节点" data-url="'+ctx+'/activityDisplay/toDis?defId='+escapeHtml(v.processDefinitionId)+'&insId='+escapeHtml(v.id)+'" >查看节点</a></td>' +
                         '</tr>');
                 });
                 $("#defineTaskDetails").empty().append(temp.join(""));
                 //详情分页加载
                 $("#defineTaskPage").show();
                 laypage({
                     cont: $("#defineTaskPage"),//dom，字符串id,jquery对象都可以
                     pages: data.pages,//总页数
                     curr:data.page,//表示当前页
                     skip: true,//是否展示调整
                     hash:"abcd",
                     jump: function(obj, first){
                         if(!first){
                             //得到了当前页，用于向服务端请求对应数据
                             var curr = obj.curr;
                             //此处用于请求后台，加载数据
                             renderFlowListDetails(curr,8,id,startTime,endTime);
                         }

                     }
                 });
             }else{
                 $("#defineTaskPage").hide();
                 $("#defineTaskDetails").empty().append('<tr><td class="text-center" colspan="4">暂无数据</td></tr>');
             }
         },
         complete : function(xhr,status){
             //完成后的操作
             layer.close(index);
             element.init();
             if(status=='timeout'){//超时,status还有success,error等值的情况
               ajaxTimeout.abort();
               //layer.msg("对不起，请求超时，请稍后访问");
                 msgTip("",3);
             }
          }
         });
    }
    //启动流程实例
    function convertFlow(defId){
        var index;//用于加载loading的
        var ajaxTimeout =$.ajax({
            url:ctx+"/activityDefine/convertModel/"+defId,
            method:"post",
            data:{},
            dataType:"json",
            async:false,
            timeout:6000,
            beforeSend:function(){
                //请求之前的操作
                index = layer.load(2, {
                    shade: [0.5,'#fff'] //0.1透明度的白色背景
                });
            },
            success: function (data) {
                //提示内容修改
                if(data.status=="0"){
                    //操作失败
                    msgTip(data.msg,data.status);
                }else if(data.status=="1"){
                    //表示操作成功,不提示消息内容
                    msgTip(data.msg,data.status,true,true);
                }
            },
            complete : function(xhr,status){ //请求完成后最终执行参数
                if(status=='timeout'){//超时,status还有success,error等值的情况
                    ajaxTimeout.abort();
                   // layer.msg("对不起，请求超时，请稍后访问");
                    msgTip("",3);
                }
                layer.close(index);
            }
        });

    }
    //点击启动加载流程列表
    function showStartFlowList(defId){
        var index;//用于加载loading的
        var ajaxTimeout =$.ajax({
            url:ctx+"/activityFlow/taskByDefId/"+defId,
            method:"POST",
            data:{},
            dataType:"json",
            async:false,
            timeout:6000,
            beforeSend:function(){
                //请求之前的操作
                index = layer.load(2, {
                    shade: [0.5,'#fff'] //0.1透明度的白色背景
                });
            },
            success: function (data) {
                var temp = [];
                if(data.data){
                    var info = data.data;
                    for(var key in info){
                        temp.push('<tr>' +
                            '<td><input type="checkbox" name="checkbox" data-id="'+key+'€'+info[key]+'" lay-skin="primary"/></td>' +
                            '<td>'+ key+'</td>' +
                            '<td>'+info[key]+'</td>'+
                            '</tr>');
                    }
                    $("#startFlowWin table tbody").empty().append(temp.join(""));
                    form.render();
                }else{
                    $("#startFlowWin table tbody").empty().append('<tr><td class="text-center" colspan="3">暂无数据</td></tr>');
                }
            },
            complete : function(xhr,status){
                //请求完成后最终执行参数
                layer.close(index);
                element.init();
                if(status=='timeout'){//超时,status还有success,error等值的情况
                    ajaxTimeout.abort();
                    //layer.msg("对不起，请求超时，请稍后访问");
                    msgTip("",3);
                }

            }
        });
    }


    function flowUpdate(flowId,flowStatus,aId){
        var index;
        var phoneUrl = ctx+"/activityDefine/defUpdate/"+flowStatus+"/"+flowId;
        var ajaxTimeout3 = $.ajax({
            url:phoneUrl,
            method:'POST',
            data:{},
            dataType:"json",
            async:false,
            timeout:6000,
            beforeSend:function () {
                index = layer.load(2, {
                    shade: [0.5,'#000'] //0.1透明度的白色背景
                });
            },
            success:function (data) {
                if(data.data &&data.data.length>0){
                    //layer.msg(data.msg);
                    if(data.status=="0"){
                        //操作失败
                        msgTip(data.msg,data.status);
                    }else if(data.status=="1"){
                        //表示操作成功,不提示消息内容
                        //msgTip(data.msg,data.status);
                        msgTip(data.msg,data.status,false,true);
                    }
                    var tmp = "suspend";
                    var tmsg = "挂起";
                    if(flowStatus=="suspend"){
                        tmp = "active";
                        tmsg = "激活";
                    }
                    $("#"+aId).attr("status",tmp);
                    $("#"+aId).text(tmsg);
                }
            },
           
            complete : function(XMLHttpRequest,status){ //请求完成后最终执行参数
                if(status=='timeout'){//超时,status还有success,error等值的情况
                    ajaxTimeout3.abort();
                    //layer.msg("对不起，请求超时，请稍后访问");
                    msgTip("",3);
                }
                layer.close(index);
            }

        });

    }

    function startFlow(tfmt){
        $("")

    }

});


