/**
 * Created by fengyang on 2017/5/19.
 */
layui.use(['form','element','layer','laypage','upload'], function () {
    var element = layui.element(),form =layui.form() ,layer = layui.layer,$ = layui.jquery,laypage = layui.laypage;
    var layerHeight = $(window).height();//计算弹框高度使用
    var layerWidth = $(window).width();//计算弹框宽度使用
    var sort_type = "time-sort-down";
    //上传文件操作
    layui.upload({
        url: ctx+"/activityDeployment/deploy",
        elem: '', //指定原始元素，默认直接查找class="layui-upload-file"
        method: 'post', //上传接口的http类型
        before: function(input){
            //返回的参数item，即为当前的input DOM对象
            //console.log('文件上传中');
        },
        success: function(res){
            if(res.status=="0"){
                //操作失败
                msgTip(res.msg,res.status);
            }else if(res.status=="1"){
                //表示操作成功,不提示消息内容
                msgTip(res.msg,res.status);
                location.reload();
            }
        },
        error:function () {
            msgTip("文件上传失败","0");
        }
    });
    
    //页面初始化加载默认第一页
    renderDeployments(1,8,sort_type,$("#deployName").val());

    //点击事件
    $(document).on("click",".show-detail", function () {
        var id = $(this).attr("pid");
        var deployDetailData= renderDeployDetails(1,8,id);
        //详情分页加载
        laypage({
            cont: $("#deployDetailPage"),//dom，字符串id,jquery对象都可以
            pages: deployDetailData.pages,//总页数
            curr:deployDetailData.page,//表示当前页
            skip: true,//是否展示调整
            hash:"abcd",
            jump: function(obj, first){
                if(!first) {
                    //得到了当前页，用于向服务端请求对应数据
                    var curr = obj.curr;
                    //此处用于请求后台，加载数据
                    renderDeployDetails(curr, 8, id);
                }
            }
        });
        var width = parseInt(layerWidth*0.44);
        var height = parseInt(layerHeight*0.76);
        var openIndex= layer.open({
            type:1,
            skin: 'layui-layer-molv',
            offset:"10px",
            title:"详情列表",
            content:$("#deployDetailList"),
            area: ['700px',height+'px'],
            btn:['关闭'],
            yes:function(){
                layer.close(openIndex);
            }
        });

    });
    //排序事件
    $(document).on("click",".sort-icon",function () {
        //刷新列表
        sort_type =  $(this).attr("data-attr");//获取排序的名称

        var startTime = $("#startTime").val();
        var endTime = $("#endTime").val();
        renderDeployments(1,8,sort_type,$("#deployName").val());
        //样式修改
        $(this).siblings().show();
        $(this).hide();
    });
    //搜索功能
    form.on("submit(searchDeployList)",function (data) {
        //往后台传递数据查询，按时间搜索
        renderDeployments(1,8,sort_type,$("#deployName").val());
        return false;
    });
    //查询方法
    $(document).on("click","#searchList",function () {
        var sortType =  $(".main-sort:visible").attr("data-attr");//获取排序的名称
        $("#deployName").val($("#deployName").val().trim());
        renderDeployments(1,8,sortType,$("#deployName").val());
    });
    //删除事件
    $(document).on("click","button[lay-filter='deleteProcess']", function () {
        var $this = $(this);
        var index = layer.confirm('您确定要删除吗？', {
            title:'删除操作',
            btn: ['确定','取消'] //按钮
        }, function(){
            var did = $this.attr("pid");
            var ajaxTimeout =$.ajax({
                url:ctx+"/activityDeployment/delete/"+did,
                method:"",
                data:{},
                dataType:"json",
                async:false,
                timeout:6000,
                beforeSend:function(){
                    //请求之前的操作
                    index = layer.load(2, {
                        shade: [0.5,'#000'] //0.1透明度的白色背景
                    });
                },
                success: function (data) {
                    if(data.status=="0"){
                        msgTip(data.msg,data.status);
                    }else if(data.status=="1"){
                        //表示操作成功,不提示消息内容
                        msgTip(data.msg,data.status,true);
                        $this.closest("tr").remove();
                    }
                },
                complete : function(xhr,status){ //请求完成后最终执行参数
                    if(status=='timeout'){//超时,status还有success,error等值的情况
                        ajaxTimeout.abort();
                        msgTip("",3);
                    }
                    //成功后的操作
                    layer.close(index);
                }
            });

        }, function(){
            //取消操作
        });
    });

    //渲染内容列表
    function renderDeployments(page,pageSize,sortType,name){
        /*说明：此处的page表示当前页,pageSize表示一页展示几条数据，time表示是否按时间搜索，sortType表示按照哪个字段进行排序，时间默认为降序排列*/
        //1.加载ajax流程列表请求
         var index;//用于加载loading的
         sortType  = sortType?sortType:"time-sort-down";
         var ajaxTimeout =$.ajax({
         url:ctx+"/activityDeployment/deployList/"+page+"/"+pageSize+"/"+sortType,
         method:"POST",
         data:{"name":name},
         dataType:"json",
         async:false,
         timeout:6000,
         beforeSend:function(){
         //请求之前的操作
         index = layer.load(2, {
         shade: [0.5,'#fff'] //0.1透明度的白色背景
         });
         },
         success: function (data) {
             // console.log(data);
             var temp = [];
             if(data.data &&data.data.length>0){
                 //删除权限
                 var delDeployDisable ="";
                 if($.trim($("#authList .deploy-delete").html())!="true"){
                     //没有权限
                     delDeployDisable = disabled="disabled";
                 }
                 //拼接字符串
                 $.each(data.data, function (i,v) {
                     temp.push('<tr>' +
                         '<td>'+ escapeHtml(v.id)+'</td>' +
                         '<td><a class="text-blue show-detail"  pid="'+escapeHtml(v.id)+'" title="详情列表">'+escapeHtml(v.name)+'</a></td>' +
                         // '<td>'+escapeHtml(v.deploymentTime)+'</td>' +
                         '<td>'+new Date(escapeHtml(v.deploymentTime)).Format("yyyy-MM-dd hh:mm:ss")+'</td>' +
                         '<td><button class="layui-btn layui-btn-sm' +
                         'all layui-btn-danger" lay-filter="deleteProcess" '+delDeployDisable+' pid="'+escapeHtml(v.id)+'">删除</button></td>' +
                         '</tr>');
                 });
                 $("#deployments").empty().append(temp.join(""));
                 $("#deployPage").show();
                 //列表分页加载
                 laypage({
                     cont: $("#deployPage"),//dom，字符串id,jquery对象都可以
                     pages: data.pages,//总页数
                     curr:data.page,//表示当前页
                     skip: true,//是否展示调整
                     hash:"abc",
                     jump: function(obj, first){
                         if(!first){
                             //得到了当前页，用于向服务端请求对应数据
                             var curr = obj.curr;
                             //此处用于请求后台，加载数据
                             renderDeployments(curr,8,sortType,name);
                         }

                     }
                 });

             }else{
                 $("#deployPage").hide();
                 $("#deployments").empty().append('<tr><td class="text-center" colspan="4">暂无数据</td></tr>');
             }


         },
         complete : function(xhr,status){
             //成功后的操作
             layer.close(index);
             element.init();
             if(status=='timeout'){//超时,status还有success,error等值的情况
             ajaxTimeout.abort();
                msgTip("",3);
             }

         }
         });
        // return result;

    }
    //渲染详情列表
    function renderDeployDetails(page,pageSize,id){
        //ajax请求
        var result = {"pages":"1","page":"1"};
         var index;//用于加载loading的
         var ajaxTimeout =$.ajax({
             url:ctx+"/activityDefine/flowDefDepList/"+id+"/"+page+"/"+pageSize,
            method:"",
            data:{},
            dataType:"json",
            async:false,
            timeout:6000,
            beforeSend:function(){
                 //请求之前的操作
                 index = layer.load(2, {
                 shade: [0.5,'#000'] //0.1透明度的白色背景
                 });
             },
         success: function (data) {
             var temp = [];
             if(data.data &&data.data.length>0){
                 //拼接字符串
                 $.each(data.data, function (i,v) {
                     temp.push('<tr>' +
                         '<td>'+ escapeHtml(v.id)+'</td>' +
                         '<td>'+escapeHtml(v.name)+'</td>'+
                         '<td>'+escapeHtml(v.version)+'</td>' +
                         '<td>'+escapeHtml(v.key)+'</td>' +
                        /* '<td>' +
                         '<a href="'+ctx+'/activityDisplay/toDis?defId='+escapeHtml(v.id)+'" target="_blank"><button class="layui-btn layui-btn-small layui-btn-warm" lay-filter="showProcess"><i class="layui-icon">&#xe64a;</i>查看流程图</button></a>' +
                         '</td>' +*/
                         '</tr>');
                 });
                 $("#deployDetails").empty().append(temp.join(""));
                 element.init();
                 result["pages"] = data.pages;
                 result["page"] = data.page;
             }else{
                 temp.push('<tr>' +
                     '<td colspan="4" align="center">没有数据</td>' +
                     '</tr>');
                 $("#deployDetails").empty().append(temp.join(""));
                 element.init();
             }
         },
         complete : function(xhr,status){ //请求完成后最终执行参数
         if(status=='timeout'){//超时,status还有success,error等值的情况
         ajaxTimeout.abort();
             msgTip("",3);
         }
         layer.close(index);
         },
         });

        return result;
    }
});
