/**
 * Created by fengyang on 2017/5/19.
 */
layui.use(['form','element','layer','laypage'], function () {
    var element = layui.element(), layer = layui.layer,$ = layui.jquery,laypage = layui.laypage,form = layui.form();
    var con_sortType = "createTime-sort-down";
    //页面初始化加载默认第一页
    var data =  renderProcessList(1,8,con_sortType);
    //分页加载
    laypage({
        cont: $(".layui-pagination"),//dom，字符串id,jquery对象都可以
        pages: data.pages,//总页数
        curr:data.page,//表示当前页
        skip: true,//是否展示调整
        hash:"abc",
        jump: function(obj, first){
            if(!first){
            //得到了当前页，用于向服务端请求对应数据
            var curr = obj.curr;
            //此处用于请求后台，加载数据
            renderProcessList(curr,8,con_sortType);
            }
        }
    });

    //详情排序事件
    $(document).on("click",".main-sort",function () {
        //刷新列表
        con_sortType =  $(this).attr("data-attr");//获取排序的名称
        renderProcessList(1,8,con_sortType);
        $(this).siblings().show();
        $(this).hide();
    });

    //删除事件
    $(document).on("click","a[lay-filter='deleteProcess']", function () {
        if(!$(this).hasClass("disabled")){
            var $this = $(this);
            var index = layer.confirm('您确定要删除吗？', {
                btn: ['确定','取消'] //按钮
            }, function(){
                var did = $this.attr("pid");
                var ajaxTimeout =$.ajax({
                    url:ctx+"/activityModel/delete/"+did,
                    method:"",
                    data:{},
                    dataType:"json",
                    async:false,
                    timeout:6000,
                    beforeSend:function(){
                        //请求之前的操作
                        index = layer.load(2, {
                            shade: [0.5,'#000'] //0.1透明度的白色背景
                        });
                    },
                    success: function (data) {
                        // layer.msg(data.msg);
                        if(data.status=="0"){
                            //操作失败
                            msgTip(data.msg,data.status);
                        }else if(data.status=="1"){
                            //表示操作成功,不提示消息内容
                            msgTip(data.msg,data.status,true);
                            $this.closest("tr").remove();
                        }

                    },
                    complete : function(xhr,status){ //请求完成后最终执行参数
                        if(status=='timeout'){//超时,status还有success,error等值的情况
                            ajaxTimeout.abort();
                            //layer.msg("对不起，请求超时，请稍后访问");
                            msgTip("",3);
                        }
                        //成功后的操作
                        layer.close(index);
                    }
                });
            }, function(){
                //取消操作
            });
        }
    });

    //部署
    $(document).on("click","a[lay-filter='deployProcess']", function () {
        if(!$(this).hasClass("disabled")){
            var did = $(this).attr("pid");
            var ajaxTimeout =$.ajax({
                url:ctx+"/activityModel/deploy/"+did,
                method:"",
                data:{},
                dataType:"json",
                async:false,
                timeout:6000,
                beforeSend:function(){
                    //请求之前的操作
                    index = layer.load(2, {
                        shade: [0.5,'#000'] //0.1透明度的白色背景
                    });
                },
                success: function (data) {
                    if(data.status=="0"){
                        //操作失败
                        msgTip(data.msg,data.status);
                    }else if(data.status=="1"){
                        //表示操作成功,不提示消息内容
                        //msgTip(data.msg,data.status);
                        msgTip(data.msg,data.status,true,true);
                    }
                },
                complete : function(xhr,status){ //请求完成后最终执行参数
                    if(status=='timeout'){//超时,status还有success,error等值的情况
                        ajaxTimeout.abort();
                        // layer.msg("对不起，请求超时，请稍后访问");
                        msgTip("",3);
                    }
                    //成功后的操作
                    layer.close(index);
                }
            });
        }
    });

    //渲染内容
    function renderProcessList(page,pageSize,sortType){
        /*说明：此处的page表示当前页*/
        //1.加载ajax流程列表请求
         var index;//用于加载loading的
        sortType = sortType?sortType:"id-sort-down";

        var result = {"pages":"1","page":"1"};
         var ajaxTimeout =$.ajax({
         url:ctx+"/activityModel/modelList/"+page+"/"+pageSize+"/"+sortType,
         method:"",
         data:{},
         dataType:"json",
         async:false,
         timeout:6000,
         beforeSend:function(){
         //请求之前的操作
           index = layer.load(2, {
            shade: [0.5,'#000'] //0.1透明度的白色背景
         });
         },
         success: function (data) {

             var temp = [];
             var state="";
             if(data.data &&data.data.length>0){
                 //编辑权限
                 var editModelDisable ="";
                 if($.trim($("#authList .model-toEdit").html())!="true"){
                     //没有权限
                     editModelDisable = "disabled";
                 }
                 //导出权限
                 var exportModelDisable ="";
                 if($.trim($("#authList .model-export").html())!="true"){
                     //没有权限
                     exportModelDisable = "disabled";
                 }
                 //部署权限
                 var deployModelDisable ="";
                 if($.trim($("#authList .model-deploy").html())!="true"){
                     //没有权限
                     deployModelDisable = "disabled";
                 }
                 //删除权限
                 var delModelDisable ="";
                 if($.trim($("#authList .model-delete").html())!="true"){
                     //没有权限
                     delModelDisable = "disabled";
                 }

                 //拼接字符串
                 $.each(data.data, function (i,v) {
                     var tmp = "";
                     var  editFlag = '<a href="'+ctx+'/activityModel/toEdit/'+escapeHtml(v.id)+'" class="text-blue" target="_blank">编辑</a>';
                     var exportFlag = '<a href="'+ctx+'/activityModel/export/'+escapeHtml(v.id)+'/xml" class="text-blue '+exportModelDisable+'" target="_blank">导出</a> ';
                     if(v.key){
                         tmp = escapeHtml(v.key);
                     }
                     if(editModelDisable=="disabled"){
                         editFlag = '<a class="'+editModelDisable+'">编辑</a>'
                     }
                     if(exportModelDisable=="disabled"){
                         exportFlag = '<a class="'+editModelDisable+'">导出</a>'
                     }
                     temp.push('<tr>' +
                         '<td>'+ escapeHtml(v.id)+'</td>' +
                         '<td>'+tmp+'</td>' +
                         '<td>'+escapeHtml(v.name)+'</td>' +
                         '<td>'+escapeHtml(v.version)+'</td>' +
                         //'<td>'+escapeHtml(v.createTime)+'</td>' +
                         '<td>'+new Date(escapeHtml(v.createTime)).Format("yyyy-MM-dd hh:mm:ss")+'</td>' +
                          //'<td>'+escapeHtml(v.lastUpdateTime)+'</td>' +
                         '<td>'+new Date(escapeHtml(v.lastUpdateTime)).Format("yyyy-MM-dd hh:mm:ss")+'</td>' +
                         '<td>'+escapeHtml(v.metaInfo)+'</td>' +
                         '<td>' +
                         '' +editFlag+
                         ' | '+
                         //'<a href="'+ctx+'/display/jsp/modeler.jsp?modeId='+escapeHtml(v.id)+'" class="text-blue" target="_blank">编辑</a>' +
                         '<a  class="text-blue '+deployModelDisable+'" lay-filter="deployProcess" pid="'+escapeHtml(v.id)+'">部署</a>' +
                         ' | '+
                         '' +exportFlag+
                         ' | '+
                         // ' |&nbsp;<a href="${ctx}/workflow/model/export/${model.id}/json" class="text-blue" target="_blank">JSON</a> ' +
                         // ' |&nbsp;<a href="#" class="text-blue">SVG</a>)' +
                         '<a class="text-blue  '+delModelDisable+'" lay-filter="deleteProcess" pid="'+escapeHtml(v.id)+'">删除</a></td>' +
                         '</tr>');
                 });
                 $("#modelList").empty().append(temp.join(""));
                 element.init();
                 result["pages"] = data.pages;
                 result["page"] = data.page;

             }

         },
         complete : function(xhr,status){ //请求完成后最终执行参数
             if(status=='timeout'){//超时,status还有success,error等值的情况
             ajaxTimeout.abort();
             ///layer.msg("对不起，请求超时，请稍后访问");
                 msgTip("",3);
             }
             //成功后的操作
             layer.close(index);
         }
         });

        return result;

    }

    //新增
    var addModelIndex;
    $(document).on("click","#addModel", function () {
        addModelIndex=layer.open({
            type:1,
            offset:'50px',
            title:"新增model",
            skin: 'layui-layer-molv',
            content:$("#addModelWin"),
            area: ['380px', 'auto']
        });

    });

    //提交新增的表单
    form.on("submit(confirmAddModel)",function () {
        layer.close(addModelIndex);
    });

    //自定义验证规则
    form.verify({
        modelDescLen:function (value,item) {
            //限制textarea长度
            if(value && !/d{0,50}/g.test(value)){
                return '模型描述不能超过50个字符';
            }
        },
        modelNameLen:function (value,item) {
            //限制角色长度
            if(value && !/d{0,20}/g.test(value)){
                return '模型名称不能超过20个字符';
            }
        },
        filterChar:function (value,item) {
            if(value){
                if(!new RegExp("^[a-zA-Z0-9_\u4e00-\u9fa5]+$").test(value)){
                    return '输入内容不能包含特殊字符';
                }
            }
        },
        filterDescChar:function (value,item) {
            if(value){
                if(!new RegExp("^[a-zA-Z0-9_\u4e00-\u9fa5\\s.。，,]*$").test(value)){
                    return '描述内容不能包含特殊字符';
                }
            }
        }

    });

});


