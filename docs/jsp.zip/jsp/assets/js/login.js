/**
 * Created by fengyang on 2017/4/19.
 */
/*layui引入需要使用的模块*/
layui.use(['layer','form'], function() {
    'use strict';
    var $ = layui.jquery, layer = layui.layer, form = layui.form();
    /*页面炫的背景*/
    $(function() {
        $("#canvas").jParticle({
            background: "#141414",
            color: "#E5E5E5"
        })
    });
    /*页面重载*/
    $(window).on('resize',
        function() {
            var w = $(window).outerWidth();
            var h = $(window).outerHeight();
            //alert("宽："+w +"高："+h);
            $(".larry-canvas").width(w).height(h);
            $("#canvas").jParticle({
                background: "#141414",
                color: "#E5E5E5"
            })
        }).resize();
    //忘记密码点击事件
    $("#forgot-password").on("click", function () {
        //表单重置
        $("#reset1").click();
        $("#login-form").slideUp();
        $("#forgot-password-form").slideDown();
        $('#captchaImage2').attr("src", "captcha?timestamp=" + new Date().getTime());//进入忘记密码页面的图形验证码加载
    });
    //返回登录按钮点击事件
    $("#go-back-login").on("click", function () {
        $("#login-form").slideDown();
        $("#forgot-password-form").slideUp();
        $('#captchaImage').attr("src", "captcha?timestamp=" + new Date().getTime());//图形验证码执行
    });
    //返回登录页面
    $("#to-login").on("click", function () {
        $("#retrievePass").slideUp();
        $("#login-form").slideDown();
        $('#captchaImage').attr("src", "captcha?timestamp=" + new Date().getTime());//图形验证码执行
    });
    //点击验证码图片更换图片
    $('#captchaImage').click(function(){
        $(this).attr("src", "captcha?timestamp=" + new Date().getTime());
    });
    /*setTimeout(function(){
        $('#captchaImage').attr("src", "captcha?timestamp=" + new Date().getTime());
    },500);*/
    $('#captchaImage2').click(function(){
        $(this).attr("src", "captcha?timestamp=" + new Date().getTime());
    });



    //自定义校验规则(该框架内置了几款校验的)
    form.verify({
        pass: [
            /^[\S]{8,12}$/
            , '密码必须8到12位，且不能出现空格'
        ],
        identical: function(value, item) { //value：表单的值、item：表单的DOM对象
            var newPass = $("#newPass").val();
            if (value!==newPass) {
                return '两次输入的密码不一致，请重新输入';
            }
        },
        phoneNum: function (value,item) {
            //value表示输入的值，item：表单的DOM对象(移动的手机号段 139、138、137、136、135、134、159、150、151、158、157、188、187、152、182、147)
            var reg = /^(139|138|137|136|135|134|159|150|151|158|157|188|187|152|182|147)\d{8}$/;
            if(!reg.test(value)){
                return "请输入合法的移动手机号码";
            }
        },
        passwordLevel:function(value,item){
            var msg;
            $.ajax({
                url:ctxStatic+"checkPswMeter",
                method:"post",
                data:{"password":value},
                cache:false,
                async: false,
                dataType:"json",
                success: function (data) {
                    if(data.data){
                        if(data.data=="1"){
                            msg= "密码强度太低，请输入8位及以上包含数字、字母或者特殊字符的密码";
                        }
                    }
                }
            });
            if(msg){
                return msg;
            }
        }
    });

    var keyCode = "";
    //找回密码事件进入下一步
    form.on('submit(confirm)', function (data) {
        //请求验证码，发送短信并请求验证码
        var ajaxTimeout1 = $.ajax({
            url:ctxStatic+"checkPhone",
            method:"POST",
            data:data.field,
            cache:false,
            async:false,
            dataType:"json",
            timeout:6000,
            beforeSend: function () {
              $("#resetPhoneNum").val($("#phoneNum").val());
            },
            success: function (data) {
               console.log(data);
                if(data.data==0){
                   layer.msg(data.msg);
                    $("#captcha2").val("");
                    $('#captchaImage2').attr("src", "captcha?timestamp=" + new Date().getTime());
                }else{
                    //发送验证码成功，进入下一步
                    //layer.msg(data.msg);
                    keyCode = data.key;
                    //表单重置
                    $("#reset2").click();
                    $("#forgot-password-form").slideUp();
                    $("#retrievePass").slideDown();
                }
            },
            complete : function(XMLHttpRequest,status){ //请求完成后最终执行参数
                if(status=='timeout'){//超时,status还有success,error等值的情况
                    ajaxTimeout1.abort();
                    layer.msg("对不起，请求超时，请稍后访问");
                }
            },
            error: function (xhr,error,msg) {
                layer.msg("对不起，你访问的页面暂时停止服务！");
            }
        });
        return false;
    });
    //进入找回密码第二步
    var passLevel;//密码强度级别
    $('#newPass').on("keyup mouseup change focusout",function () {
        var pass =$(this).val();
        if(pass){
            //延迟5毫秒发送请求
            setTimeout(function(){
                $.ajax({
                    url:ctxStatic+"checkPswMeter",
                    method:"post",
                    data:{"password":pass},
                    cache:false,
                    async: false,
                    dataType:"json",
                    success: function (data) {
                        if(data.data){
                            passLevel=data.data;
                            if (passLevel=="3") {
                                $('#level').removeClass('pw-weak');
                                $('#level').removeClass('pw-medium');
                                $('#level').removeClass('pw-strong');
                                $('#level').addClass(' pw-strong');
                                //密码为八位及以上并且字母数字特殊字符三项都包括,强度最强
                            }else if (passLevel=="2") {
                                $('#level').removeClass('pw-weak');
                                $('#level').removeClass('pw-medium');
                                $('#level').removeClass('pw-strong');
                                $('#level').addClass(' pw-medium');
                                //密码为八位及以上并且字母、数字、特殊字符三项中有两项，强度是中等
                            }else if(passLevel=="1"){
                                $('#level').removeClass('pw-weak');
                                $('#level').removeClass('pw-medium');
                                $('#level').removeClass('pw-strong');
                                $('#level').addClass('pw-weak');
                                //如果密码为8位，纯数字或者字母等表示为弱密码
                            }
                        }
                    }
                });
            },500);
        }else{
            $('#level').removeClass('pw-weak');
            $('#level').removeClass('pw-medium');
            $('#level').removeClass('pw-strong');
            $('#level').addClass(' pw-defule');
        }
    });
    form.on('submit(retrieve-password)', function (data) {
        //输入新密码,后台请求，根据后台返回的消息看是否找回密码成功
        var ajaxTimeout2 = $.ajax({
            url:ctxStatic+"resetPassword",
            method:"POST",
            data:data.field,
            cache:false,
            async:false,
            dataType:"json",
            timeout:6000,
            beforeSend: function () {
            },
            success: function (data) {
                if(data.data==0){
                    //修改密码错误
                    layer.msg(data.msg);
                   /* $("#reset1").click();*/
                   /* $("#retrievePass").slideUp();
                    $("#forgot-password-form").slideDown();*/
                }else if(data.data==1){
                   //修改密码成功，调转到登录页面
                    layer.msg(data.msg);
                    $("#retrievePass").slideUp();
                    $("#login-form").slideDown();
                }
            },
            complete : function(XMLHttpRequest,status){ //请求完成后最终执行参数
                if(status=='timeout'){//超时,status还有success,error等值的情况
                    ajaxTimeout2.abort();
                    layer.msg("对不起，请求超时，请稍后访问");
                }
            },
            error: function (xhr,error,msg) {
                layer.msg("对不起，你访问的页面暂时停止服务！");
            }
        });
        return false;
    });
      //短信倒计时功能
    $("#getPhoneNum").on("click",function () {
        settime($(this));
        //后台调取发送短信的方法
        var ajaxTimeout3 = $.ajax({
            url:ctxStatic+"getSmsCaptcha",
            method:"POST",
            data:{key:keyCode},
            cache:false,
            async:false,
            dataType:"json",
            timeout:6000,
            beforeSend: function () {
            },
            success: function (data) {
               if(data.data=="0"){
                   layer.msg(data.msg);
               }
            },
            complete : function(XMLHttpRequest,status){ //请求完成后最终执行参数
                if(status=='timeout'){//超时,status还有success,error等值的情况
                    ajaxTimeout3.abort();
                    layer.msg("对不起，请求超时，请稍后访问");
                }
            },
            error: function (xhr,error,msg) {
                layer.msg("短信未发送成功，请稍后再试");
            }
        });

    });
    //倒计时功能
    var countdown=60;
    function settime(obj) {
        if (countdown == 0) {
            obj.prop("disabled",false);
            obj.html("免费获取验证码");
            countdown = 60;
            return;
        }else{
            obj.prop("disabled", true);
            obj.html("重新发送(" + countdown + ")");
            countdown--;
        }
        setTimeout(function() {
                settime(obj)
        },1000)
    }

});