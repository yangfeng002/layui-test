/**
 * Created by fengyang on 2017/4/28.
 */
/*引入相关文件*/
layui.use(['element','layer','util'],function() {
    //1.服务引入
    var element = layui.element(), layer = layui.layer,$ = layui.jquery;
    var globalIp = "";//控制ip使用的
    var globalIndex = "";//初始化
    var chart1 = echarts.init(document.getElementById("cpuContainer"));
    var chart2 = echarts.init(document.getElementById("storageContainer"));
    var chart3 = echarts.init(document.getElementById("exchangeContainer"));
    var chart4 = echarts.init(document.getElementById("discContainer"));
    var globaloption = {
        tooltip : {
            formatter: "{a} <br/>{b} : {c}%"
        },
        toolbox: {
            feature: {
                restore: {},
                saveAsImage: {}
            }
        },
        series: [
            {
                axisLine: {
                    show: true,
                    lineStyle: {
                        width: 10,
                        shadowBlur: 0,
                        color:[[0.75, '#7CBB55'],[0.85, '#DDBD4D'],[1.0, '#E43F3D']]
                    }
                },
                axisTick: {
                    show: false,
                    splitNumber: 1
                },
                axisLabel:{
                    distance:0,
                    show:true
                },
                splitLine:{
                    show: false,
                },
                name: "",
                type: 'gauge',
                radius:'100%',
                detail: {
                    formatter:'{value}%',
                    offsetCenter: [0, "60%"],
                    textStyle: {
                        fontSize: 20,
                        color: "#333"
                    }},
                data: [{value: "", name: ""}]
            }
        ]
    };
    $(window).bind('scroll',function(){
        var len=$(this).scrollTop();
        if(len>=100){
            //显示回到顶部按钮
            $('.layui-fixbar').show();
        }else{
            //隐藏回到顶部按钮
            $('.layui-fixbar').hide();
        }
    });
    $('.layui-fixbar-top').click(function(){
        //不需要动画则直接
        $(document).scrollTop(0);
    });
    //2.业务逻辑功能部分
    //2.1服务器列表动态加载（展示当前服务器的信息）
    getAllHost();
    //服务器列表事件绑定
    $(document).on("click",".monitor-nav li", function () {
        $(this).siblings().removeClass("current");
        $(this).addClass("current");
        //ajax请求（服务器详细信息加载）
        var ip = $(this).attr("data-ip");
        var runStatus =  $(this).attr("data-status");
        globalIp=ip;//更改全局的IP
        getHostDetail(ip,runStatus);
    });

    //定时器
    setInterval(function () {
        getAllHost();
    },3000);

    //服务器列表信息
    function getAllHost(data) {
        var index;
        var url = ctxStatic+"monitor/getAllHost";
        var ajaxTimeout = $.ajax({
            url:url,
            method:"post",
            async:true,//是否为异步请求
            data:{},//请求的参数
            cache:false,//是否取缓存
            dataType:"json",//后台返回值的类型
            timeout:6000,
            beforeSend: function () {
                //调用之前进行加载
               /* index = layer.load(2, {
                    shade: [0.5,'#000'] //0.1透明度的白色背景
                });*/
            },
            success: function (data) {
                //执行列表加载并处理数据
                //layer.close(index);
                var temp = [];
                var info = "normal";//当前IP状态
                if(data.hostData && data.hostData.length>0){
                    $.each(data.hostData, function (i,v) {
                        var curr;
                        if(globalIp){
                            if(globalIp==v.ip){
                                curr =" current";
                                globalIp=v.ip;
                            }
                        }else{
                            if(i==0){
                                //如果没有选中，那么默认第一个选中状态
                                curr =" current";
                                globalIp=v.ip;
                            }
                        }
                        if(v.state=="2"){
                            //危险状态
                            info ="danger";
                        }else if(v.state=="1"){
                            //警告状态
                            info = "warning"
                        }else if(v.state=="0"){
                            //正常状态
                            info = "normal";
                        }else if(v.state=="3"){
                            info="danger";
                        }
                        temp.push('<li data-status="'+v.state+'" class="layui-elip '+ info+curr+'" data-ip="'+v.ip+'">' +
                            '<a  title="'+v.app+':'+ v.ip+'" >' +
                            '<i class="iconfont icon-diannao1 text-'+info+'"></i>' +
                            '<span>'+ v.app+'</span>:<span>'+ v.ip+'</span>'+
                            '</a></li>');
                    });
                    $(".monitor-nav").empty().append(temp.join(""));
                    element.init();
                    //初始化调用详情信息
                    var ip = $(".monitor-nav li.current").attr("data-ip");
                    var runStatus = $(".monitor-nav li.current").attr("data-status");
                    getHostDetail(ip,runStatus);
                }
            },
            complete : function(XMLHttpRequest,status){ //请求完成后最终执行参数
                if(status=='timeout'){//超时,status还有success,error等值的情况
                    ajaxTimeout.abort();
                    //layer.msg("对不起，请求超时，请稍后访问");
                    msgTip("",3);
                }
            }
           
        });
    }
    //单独一个服务器的请求
    function getHostDetail(ip,runStatus) {
        var index;
        var url = ctxStatic+"monitor/getOneHost";
       var ajaxTimeout2 =  $.ajax({
            url:url,
            method:"post",
            data:{ip:ip},
            cache:false,
            async:false,
            dataType:"json",
            timeout:6000,
            beforeSend: function () {
                //调用之前进行加载
               /* index = layer.load(2, {
                    shade: [0.5,'#000'] //0.1透明度的白色背景
                });*/
            },
            success: function (data) {
//                 layer.close(index);
                //执行列表加载并处理数据

                getOption(data.pcCpuUtilization,"占比","cpu",chart1,runStatus);
                getOption(data.pcMemoryUtilization,"使用量","内存",chart2,runStatus);
                getOption(data.pcSwapUtilization,"使用量","交换区",chart3,runStatus);
                getOption(data.usedFileUtilization,"使用量","磁盘",chart4,runStatus);

                //数据处理
                $.map(data, function (item, index) {
                    //console.log(arrval+"==="+key1);
                    //如果返回的状态是服务器停止，那么页面显示的可以是“--”
                    if(runStatus==3){
                        item ="暂无数据";
                        $(".monitor-content>blockquote").removeClass("layui-hide");
                    }else{
                        $(".monitor-content>blockquote").addClass("layui-hide");
                    }
                    if(index){
                        $('.' + index).text(item);
                    }
                });
                element.init();
            },
           complete : function(XMLHttpRequest,status){ //请求完成后最终执行参数
               if(status=='timeout'){//超时,status还有success,error等值的情况
                   ajaxTimeout2.abort();
                   //layer.msg("对不起，请求超时，请稍后访问");
                   msgTip("",3);
               }
           }
        });
    }
    //调用接口(echarts生成)
    function getOption(value,title1,title2,chart,runStatus){
        /*value表示修改的值，title1和title2是修改的名称值，chart表示初始化的echart对象 runStatus如果为3，那么展示数据为0*/
        value = runStatus==3?"0.00%":value;
        if(value){
            globaloption.series[0].data[0].value = (value).replace("%","");
        }else{
            globaloption.series[0].data[0].value = "0.00";
        }
        globaloption.series[0].data[0].name = title1;
        globaloption.series[0].name=title2;
        chart.setOption(globaloption,true);
    }
});