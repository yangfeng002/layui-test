/**
 * Created by fengyang on 2017/4/28.
 */
/*引入相关文件*/
layui.use(['element','layer','util','form'],function() {
    //1.服务引入
    var element = layui.element(), layer = layui.layer,form =layui.form(),$ = layui.jquery;
    //自定义验证规则
    form.verify({
        heartbeatValue: function (value, item) {
            if(value>60 || value<1){
                return "您输入的数据有误，请设置1-60之间的值";
            }
        },
        heartbeatValue1: function (value, item) {
            if(value>60 || value<1){
                return "您输入的数据有误，请设置1-60之间的值";
            }
        },
        heartbeatValue2: function (value, item) {
            if(value<=60 && value>=0.1){
                
            }else{
            	return "您输入的数据有误，请设置0.1-60之间的值";
            }
        },
        compare1:function (value,item) {
           if(value<=$(".timeInterval").val()){
              return "心跳停止时长不能小于或者等于监控时间间隔";
           }
        },
        compare2:function (value,item) {
            if(value>=$(".heartInterval").val()){
                return "监控时间间隔不能大于或者等于心跳停止时长";
            }
        },
        jvmValue:function (value, item) {
            if(value>99 || value <10){
                return "您输入的数据有误，请设置10-99之间的值";
            }
        },
        phoneNum: function (value,item) {
            //value表示输入的值，item：表单的DOM对象(移动的手机号段 139、138、137、136、135、134、159、150、151、158、157、188、187、152、182、147)
            var reg = /^(139|138|137|136|135|134|159|150|151|158|157|188|187|152|182|147)\d{8}$/;
            if(!reg.test(value)){
              return "请输入合法的移动手机号码";
            }
        },
        username:function (value,item) {
            if(!new RegExp("^[a-zA-Z0-9_\u4e00-\u9fa5\\s·]+$").test(value)){
                return '用户名不能有特殊字符';
            }
        }

    });

    //tab点击事件
      $(".migu-tab li").on("click",function () {
        var dataUrl = $(this).attr("data-url");
        if(dataUrl=="1"){
          //调用阀值的接口
            var index;
            var url = ctxStatic+"threshold/getAllThreshold";
            $.ajax({
                url:url,
                method:"post",
                data:{},
                cache:false,
                dataType:"json",
                beforeSend: function () {
                    //调用之前进行加载
                    index = layer.load(2, {
                        shade: [0.5,'#000'] //0.1透明度的白色背景
                    });
                },
                success: function (data) {
                    //执行列表加载并处理数据
                    layer.close(index);
                    //{"data":[{"id":"MT001","parts":"JVM?????%?","threshold":80.0},{"id":"MT002","parts":"??????????","threshold":3.0},{"id":"MT003","parts":"JVM????????","threshold":3.0}]}
                    //处理按钮权限控制
                    var editThresholdDisable ="";
                    if($.trim($("#authList .editThreshold").html())!="true"){
                        //没有权限
                        editThresholdDisable = disabled="disabled";
                    }
                    var temp = [];
                    var interval = '';
                    var monitorInterval="";
                    $.each(data.data, function (i,v) {
                         if(v.id=="MT001"){
                           interval = 'required|number|jvmValue';
                         }else if(v.id=="MT002"){
                             interval = "required|number|heartbeatValue";
                             monitorInterval = "heartInterval";
                         }else if(v.id=="MT003"){
                             interval = "required|number|heartbeatValue1";
                         }else if(v.id=="MT004"){
                           interval = "required|heartbeatValue2|compare2";
                             monitorInterval = "timeInterval";
                         }
                        temp.push('<tr><td>'+v.id+'</td><td>'+ v.parts+'</td>' +
                            '         <td><input  name="" lay-verify="'+interval+'"  value="'+v.threshold+'" readonly="readonly"  class="no-border '+monitorInterval+'"></td>' +
                            '         <td class="handler"><a><button '+editThresholdDisable+'  class="layui-btn layui-btn-small"  lay-filter="editor"><i class="layui-icon">&#xe642;</i>编辑</button>' +
                            '                <button class="layui-btn layui-btn-small layui-btn-warm btn-save"  '+editThresholdDisable+' lay-submit="" lay-filter="save"><i class="layui-icon">&#xe618;</i>保存</button> ' +
                            '            </a>' +
                            '         </td>' +
                            '    </tr>');
                    });
                    $("#threshold").empty().append(temp.join(""));
                    element.init();
                }
            });
        }else if(dataUrl=="2"){
           //调用手机号码的接口
            var index;
            var phoneUrl = ctxStatic+"threshold/getAllMonitorPhone";
            var ajaxTimeout = $.ajax({
                url:phoneUrl,
                method:'post',
                data:{},
                dataType:"json",
                async:false,
                timeout:6000,
                beforeSend:function () {
                    index = layer.load(2, {
                        shade: [0.5,'#000'] //0.1透明度的白色背景
                    });
                },
                success:function (data) {
                    //{"data":[{"ID":"1234","PHONE_NUMBER":"1222","PHONE_NAME":"ss2"}]}
                    layer.close(index);
                    //告警手机号编辑保存新增按钮权限控制
                    var editMonitorPhoneDisable = "";
                    if($.trim($("#authList .editMonitorPhone").html())!="true"){
                        //没有权限
                        editMonitorPhoneDisable = disabled="disabled";
                    }
                    //告警手机号删除权限控制
                    var delMonitorPhoneDisable = "";
                    if($.trim($("#authList .delMonitorPhone").html())!="true"){
                        //没有权限
                        delMonitorPhoneDisable = disabled="disabled";
                    }
                    var temp = [];
                    $.each(data.data, function (i,v) {
                        temp.push('<tr>' +
                            ' <td><input type="hidden" value="'+v.ID+'">'+(i+1)+'</td>' +
                            '<td><input placeholder="" name="username" autocomplete="off" value="'+ v.PHONE_NAME+'"  lay-verify="required|username"  readonly="readonly" class="no-border"/></td> ' +
                            '<td><input placeholder="" name="phonenum" autocomplete="off" value="'+ v.PHONE_NUMBER+'" lay-verify="required|phoneNum" maxlength="11" readonly="readonly" class="no-border"/>' + '</td> ' +
                            '<td><a> ' +
                            '    <button  '+editMonitorPhoneDisable+' class="layui-btn layui-btn-normal layui-btn-small" lay-filter="editorPhone"><i class="layui-icon">&#xe642;</i>编辑</button>' +
                            '    <button '+delMonitorPhoneDisable+' class="layui-btn layui-btn-danger  layui-btn-small" lay-filter="deletePhone"><i class="layui-icon">&#xe640;</i>删除</button> ' +
                            '    <button '+editMonitorPhoneDisable+' class="layui-btn layui-btn-warm layui-btn-small" lay-submit="" lay-filter="savePhone"><i class="layui-icon">&#xe618;</i>保存</button>'+
                            '   </a></td>' +
                            '</tr>');
                    });
                    $("#phone").empty().append(temp.join(""));
                    element.init();
                },
                complete : function(XMLHttpRequest,status){ //请求完成后最终执行参数
                    if(status=='timeout'){//超时,status还有success,error等值的情况
                        ajaxTimeout.abort();
                        //layer.msg("对不起，请求超时，请稍后访问");
                        msgTip("",3);
                    }
                },
            });
        }
    });
      $(".migu-tab li.layui-this").trigger("click");

    //阀值编辑事件
     $(document).on("click","button[lay-filter='editor']",function () {
        $(this).closest("td").prev().find("input").attr("readonly",false);
        $(this).closest("td").prev().find("input").focus();
     });
     //告警阀值保存事件
     form.on('submit(save)', function(data){
        //往后台调用并进行验证
        var url = ctxStatic+"threshold/editThreshold";
        var id =  $(data.elem).closest("tr").find("td:eq(0)").text();
        var parts = $(data.elem).closest("tr").find("td:eq(1)").text();
        var threshold =$(data.elem).closest("td").prev().find("input").val();
        var $this = $(data.elem);
         if($(data.elem).closest("td").prev().find("input").attr("readonly")!="readonly"){
             //判断是否为编辑状态，如果是那么调用后台接口，如果不是那不操作
             $.ajax({
                 url:url,
                 method:"post",
                 data:{id:id,parts:parts,threshold:threshold},
                 //cache:false,
                 dataType:"json",
                 beforeSend:function () {
                     //请求之前做的相关操作
                 },
                 success:function (data) {
                    // console.log(data);
                     if(data.data=="1"){
                        // layer.msg(data.msg);
                         msgTip(data.msg,data.data,true);
                         $this.closest(".handler").prev("td").find("input").attr("readonly",true);
                     }else if(data.data=="0"){
                         //修改失败
                         msgTip(data.msg,data.data);
                     }
                 }
             });
         }
    });

    //告警手机号和名字编辑功能
    $(document).on('click',"button[lay-filter='editorPhone']", function () {
        var dom = $(this).closest("tr").find("input");
        $.each(dom, function (i,v) {
            $(this).attr("readonly",false) ;
            if(i==0){
                $(this).focus();
            }
        });
    });
    //手机号码删除功能
    $(document).on("click","button[lay-filter='deletePhone']", function () {
        //判断是否为最后一个，如果为最后一个那么就不能删除（提示信息），如果不为最后一个那么也提示是否要删除
        var $this = $(this);
        if($("#phone").find("tr").length==1){
            layer.alert("至少要保留一个手机号码！");
        }else{
            var id = $(this).closest("tr").find("input:hidden").val();
            var index = layer.confirm('您确定要删除吗？', {
                btn: ['确定','取消'] //按钮
            }, function(){
                //执行删除操作
                if(!id){
                   //新添加的行直接删除即可
                    $this.closest("tr").remove();
                    layer.closeAll();
                    layer.msg("删除成功");//提示内容
                }else{
                    $.post(ctxStatic+"threshold/delMonitorPhone",{id:id},function (data) {
                        if(data.data=="1"){
                            //执行删除操作
                            $this.closest("tr").remove();
                            layer.closeAll();
                        }
                        layer.msg(data.msg);//提示内容
                    },"json");
                }

            }, function(){
               //取消操作
            });
        }

    });
    //添加功能
    $("button[lay-filter='addPhone']").on("click", function(){
       //添加一行，需要判断td有多少行，如果超过10行，那么就不允许添加了。
      if($("#phone").find("tr").length<9) {
          var temp = [];
          var num =$("#phone").find("tr").length;
          temp.push('<tr>' +
              ' <td><input type="hidden" value="">'+(1+num)+'</td>' +
              '<td><input placeholder="请输入用户名" autocomplete="off" name="username" lay-verify="required" class="no-border"/></td> ' +
              '<td><input placeholder="请输入手机号码" autocomplete="off" name="phonenum" maxlength="11" value="" lay-verify="required|phoneNum" class="no-border"/>' + '</td> ' +
              '<td><a> ' +
              '    <button  class="layui-btn layui-btn-normal layui-btn-small" lay-submit="" lay-filter="editorPhone"><i class="layui-icon">&#xe642;</i>编辑</button>' +
              '    <button class="layui-btn layui-btn-danger  layui-btn-small" lay-filter="deletePhone"><i class="layui-icon">&#xe640;</i>删除</button> ' +
              '    <button class="layui-btn layui-btn-warm layui-btn-small" lay-submit="" lay-filter="savePhone"><i class="layui-icon">&#xe618;</i>保存</button>'+
              '   </a></td>' +
              '</tr>');
          $("#phone").append(temp.join(""));
      }else{
          layer.alert("不好意思，最多只能添加8行！");
      }
    });
    //告警手机号码保存功能
    form.on('submit(savePhone)', function(data){
        //往后台调用并进行验证
        var dom = $(data.elem).closest("tr").find("input:visible");
        $.each(dom, function (i,v) {
            if($(this).attr("readonly")!="readonly"){
               //执行保存操作
                var url = ctxStatic+"threshold/editMonitorPhone";
                var id =  $(data.elem).closest("tr").find("td:eq(0)").find("input").val();
                var name = $(data.elem).closest("tr").find("td:eq(1)").find("input").val();
                var phoneNum =$(data.elem).closest("td").prev().find("input").val();
                var $this = $(data.elem);
                $.ajax({
                    url:url,
                    method:"post",
                    data:{"phone_name":name,"id":id,"phone_number":phoneNum},
                    dataType:"json",
                    success:function (data) {
                        var dom = $this.closest("tr").find("input:visible");
                        $.each(dom, function (i,v) {
                            $(this).attr("readonly",true);//不可编辑
                        });
                        layer.msg(data.msg);
                        $(".migu-tab li.layui-this").trigger("click");
                    }
                });
            }
        });


    });
});