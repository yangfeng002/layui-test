/**
 * Created by fengyang on 2017/4/19.
 */
layui.use(['element','layer','util','form'],function() {
    var element = layui.element(), layer = layui.layer, $ = layui.jquery, util = layui.util,form = layui.form();
    //使用内部工具组件
    var $leftMenu = $(document).find('.left-menu');//dom元素
    var tab = 'top-tab';//切换卡（菜单详情中展示的部分）
    var topMenu = 'side-left';//一级菜单名称
    var leftMenu = 'left-menu';//二级菜单名称（是一级菜单下面的子菜单）
    var side = $('.my-side');//左侧导航
    var body = $('.my-body');//中心内容部分
    var footer = $('.my-footer');//底部对象

   //加载菜单选项
   $.ajax({
       url:ctx+"/sysMenu/getAuthorityList",
       method:"POST",
       data:{},
       dataType:"json",
       beforeSend:function () {
           
       },
       success:function (data) {
           if(data.data && data.data.length>0){
               //加载一级菜单
               var temp = [];//加载1级菜单的数组
               //首页默认加载
               temp.push('<li class="layui-nav-item layui-this"><a href="javascript:;"><i class="iconfont icon-shouye01"></i>首页</a></li>');
               var temp2 = [];
               temp2.push('<li class="layui-nav-item layui-this"><a href="javascript:;" data-url="" data-id="11">首页</a> </li>');
               $("#secondMenu").append('<ul class="layui-nav layui-nav-tree left-menu" lay-filter="left-menu" style="display: block;">'+temp2.join("")+'</ul>');
               temp2 = [];
               $.each(data.data,function(i,v){
                   //循环一级菜单
                   //var selected=(i==0)? "layui-this":"";
                   temp.push('<li class="layui-nav-item"><a href="javascript:;"><i class="iconfont '+v.ico+'"></i>'+escapeHtml(v.name)+'</a></li>');
                   //判断是否有子节点
                   var selected = "";//是否选中状态
                   var status = "none";//是否展示
                   if(v.children && v.children.length>0){
                       $.each(v.children,function (j,k) {
                         //selected = (i==0 && j==0)? "layui-this":"";
                         temp2.push('<li class="layui-nav-item"><a href="javascript:;" data-url="'+k.menu_url+'" data-id="'+(i+2)+''+(j+1)+'">'+k.name+'</a> </li>');
                       });
                       status ="none";
                       $("#secondMenu").append('<ul class="layui-nav layui-nav-tree left-menu" lay-filter="left-menu" style="display: '+status+';">'+temp2.join("")+'</ul>');
                   }else{
                       //无子节点的状态
                       status ="none";
                       //selected =(i==0)? "layui-this":"";
                       $("#secondMenu").append('<ul class="layui-nav layui-nav-tree left-menu" lay-filter="left-menu" style="display: '+status+';">' +
                           '<li class="layui-nav-item">' +
                           '<a href="javascript:;" data-url="'+v.menu_url+'" data-id="'+(i+2)+''+(1)+'">'+v.name+'</a>' +
                           '</li>' +
                           '</ul>');
                   }
                   temp2 = [];
               });
               $("#firstMenu").empty().append(temp.join(""));
           }else{
               //无数据时只添加首页菜单
               var temp = [];//加载1级菜单的数组
               //首页默认加载
               temp.push('<li class="layui-nav-item layui-this"><a href="javascript:;"><i class="iconfont icon-shouye01"></i>首页</a></li>');
               var temp2 = [];
               temp2.push('<li class="layui-nav-item layui-this"><a href="javascript:;" data-url="" data-id="11">首页</a> </li>');
               $("#secondMenu").append('<ul class="layui-nav layui-nav-tree left-menu" lay-filter="left-menu" style="display: block;">'+temp2.join("")+'</ul>');
               $("#firstMenu").empty().append(temp.join(""));
           }
           element.init();
       }
      
   });

    //一级菜单导航事件
    element.on('nav(' + topMenu + ')',function(data) {
        //控制二级菜单的展示（顺序需要保证一致）
        // $leftMenu.hide().eq(data.index()).show();
        $(document).find('.left-menu').hide().eq(data.index()).show();
        var id = $(document).find('.left-menu').eq(data.index()).children("li.layui-this").children("a").attr("data-id");
        if(id){
            //切换相应的菜单
            element.tabChange(tab,id);
        }else{
            var title = $.trim($(document).find('.left-menu').eq(data.index()).children("li:first-child").children("a").html());
            var id = $.trim($(document).find('.left-menu').eq(data.index()).children("li:first-child").children("a").attr("data-id"));
            var url =ctx+""+ $.trim($(document).find('.left-menu').eq(data.index()).children("li:first-child").children("a").attr("data-url"));
            //绑定对应的iframe
            var mainHeight = $(window).height() - 60 - 41 - 44 - 5-20;
            var length 	= $(".layui-tab-title").children("li[lay-id='" + id + "']").length;
            //&& name!='首页' id为11代表首页
            if (!length && id!='11') {
                //绑定对应的iframe
                var iframe = '<iframe src="' + url + '" style="height:' + mainHeight + 'px;width: 100%;" frameborder="0"></iframe>';
                element.tabAdd(tab, {
                    title	: title,
                    content	: iframe,
                    id		: id
                });
            }
            element.tabChange(tab, id);
            length && loadPage();
        }
    });
    // 初始化
    init();
    //var mainHeight = $(window).height() - 60 - 41 - 44 - 5;
    var mainHeight = $(window).height() - 60 - 41 - 44 - 5-20;
    //$("#frame").css({height: $(window).height()-180});//设置iframe高度
    $("#frame").css({height: $(window).height()-220});//设置iframe高度
    //二级菜单事件
    element.on('nav(' + leftMenu + ')',function(data) {
        var a 	= data.children("a");
        var name = a.html();
        var id = a.data("id");
        var url =ctx+"/"+a.data("url");
        var title 	= a.text();
        var length 	= $(".layui-tab-title").children("li[lay-id='" + id + "']").length;
        //&& name!='首页' id为11代表首页
        if (!length && id!='11') {
            //绑定对应的iframe
            var iframe = '<iframe src="' + url + '" style="height:' + mainHeight + 'px;width: 100%;" frameborder="0"></iframe>';
            element.tabAdd(tab, {
                title	: title,
                content	: iframe,
                id		: id
            });
        }
        element.tabChange(tab, id);
        length && loadPage();
        if(id=='11'){
            $(".layui-tab").find("li[lay-id=11]").addClass("layui-this").siblings().removeClass("layui-this");
            $(".layui-tab-content").find("div.layui-tab-item:first-child").addClass("layui-show").siblings().removeClass("layui-show");
        }
    });
    //二级菜单列表点击事件
    $leftMenu.on("click", "li",function() {
        $(this).siblings().removeClass("layui-nav-itemed");
    });

    /*logo点击事件*/
    $("#goHome").on("click",function () {
        element.tabChange(tab,11);
        $(".top-menu").find(".layui-nav-item:first-child").addClass("layui-this").siblings().removeClass("layui-this");;
        $(".left-menu:first-child").show().siblings().hide();
    });

    //左侧菜单收缩事件
    $(".menu-flexible").click(function(){
        if(localStorage.log == 0){
            navShow(50);
        }else{
            navHide(50);
        }
    });

    //切换tab时移除nav的layui-this样式
    element.on('tab(' + tab + ')', function(data) {
        $('ul[lay-filter=' + tab +'] .layui-this').removeClass('layui-this');
        var tabId =  $(".layui-tab-title li.layui-this").attr("lay-id");
        $.each($("#secondMenu>.left-menu"),function (i,v) {
            var $this = $(this);
            $.each($this.find("li"),function (j,u) {
                var flag = 0;//列表的顺序
                if($(this).find("a").attr("data-id")==tabId){
                    //查找到当前li,对其样式进行修改
                    $(this).addClass("layui-this").siblings().removeClass("layui-this");
                    $(this).closest(".left-menu").show().siblings().hide();
                    flag =i;
                    $(".top-menu").find("li:eq("+flag+")").addClass("layui-this").siblings().removeClass("layui-this");//1级菜单添加样式
                    return false; //退出循环
                }
            });
        });
        $(".layui-tab-close").on("click",function () {
            $.each($("#secondMenu>.left-menu"),function (i,v) {
                var $this = $(this);
                $.each($this.find("li"),function (j,u) {
                    var flag = 0;//列表的顺序
                    if($(this).find("a").attr("data-id")==tabId){
                        //查找到当前li,对其样式进行修改
                        $(this).addClass("layui-this").siblings().removeClass("layui-this");
                        $(this).closest(".left-menu").show().siblings().hide();
                        flag =i;
                        $(".top-menu").find("li:eq("+flag+")").addClass("layui-this").siblings().removeClass("layui-this");//1级菜单添加样式
                        return false; //退出循环
                    }
                });
            });
        })
    });

    $(".layui-tab-button").on("click","a",function(){loadPage()});

    // 重新载入页面
    function loadPage(){
        var index = $(".layui-tab-content").find(".layui-show").index();
        window[index].location.reload();
    }
    //退出登录
    $("a[lay-filter='logout']").on("click", function () {
        var index = layer.confirm('您确定要退出吗？', {
            title:'退出登录',
            //skin:'layui-layer-molv',
            btn: ['确定','取消'] //按钮
        }, function(){
            //确定退出
            location.href = ctxStatic+"logout";
        }, function(){
            //取消操作
        });
    });

    //修改密码页面调用
    var openIndex;
    $("a[lay-filter='modify-password']").on("click", function () {
        openIndex= layer.open({
            type:1,
            skin: 'layui-layer-molv',
            title:"修改密码",
            content:$("#modifyPassword"),
            area: ['400px', 'auto']
        });
    });
    //确认修改密码
    var passLevel;//密码强度级别
    form.on('submit(confirmUpdatePass)', function(data){
        var ajaxTimeout1 = $.ajax({
                url:ctxStatic+"modifyPassword",
                method:"post",
                data:data.field,
                cache:false,
                async:false,
                dataType:"json",
                timeout:6000,
                beforeSend: function () {
                },
                success: function (data) {
                    if(data.data==0){
                        //表示修改密码失败
                        layer.msg(data.msg);
                    }else if(data.data==1){
                        //表示修改密码成功
                        layer.msg(data.msg);
                        layer.close(openIndex);
                    }
                    element.init();
                },
                complete : function(XMLHttpRequest,status){ //请求完成后最终执行参数
                    if(status=='timeout'){//超时,status还有success,error等值的情况
                        ajaxTimeout1.abort();
                        layer.msg("对不起，请求超时，请稍后访问");
                    }
                }
            });
        return false; //阻止表单跳转。如果需要表单跳转，去掉这段即可。

    });
    $('#newPass').on("keyup mouseup change focusout",function () {
        var pass =$(this).val();
        if(pass){
            //延迟5毫秒发送请求
            setTimeout(function(){
                $.ajax({
                    url:ctxStatic+"checkPswMeter",
                    method:"post",
                    data:{"password":pass},
                    cache:false,
                    async: false,
                    dataType:"json",
                    success: function (data) {
                        if(data.data){
                            passLevel=data.data;
                            if (passLevel=="3") {
                                $('#level').removeClass('pw-weak');
                                $('#level').removeClass('pw-medium');
                                $('#level').removeClass('pw-strong');
                                $('#level').addClass(' pw-strong');
                                //密码为八位及以上并且字母数字特殊字符三项都包括,强度最强
                            }else if (passLevel=="2") {
                                $('#level').removeClass('pw-weak');
                                $('#level').removeClass('pw-medium');
                                $('#level').removeClass('pw-strong');
                                $('#level').addClass(' pw-medium');
                                //密码为八位及以上并且字母、数字、特殊字符三项中有两项，强度是中等
                            }else if(passLevel=="1"){
                                $('#level').removeClass('pw-weak');
                                $('#level').removeClass('pw-medium');
                                $('#level').removeClass('pw-strong');
                                $('#level').addClass('pw-weak');
                                //如果密码为8位，纯数字或者字母等表示为弱密码
                            }
                        }
                    }
                });
            },500);
        }else{
            $('#level').removeClass('pw-weak');
            $('#level').removeClass('pw-medium');
            $('#level').removeClass('pw-strong');
            $('#level').addClass(' pw-defule');
        }
    });

    //刷新页面
    $("#refresh_iframe").on("click",function () {
        loadPage();
    });

    /*关闭选项卡常用操作*/
    //1.关闭当前选项卡
    $("a[data-ename=closeCurrent]").on("click",function () {
       if($(".layui-tab-title").find("li.layui-this").attr("lay-id")=="11"){
           layer.alert("温馨提示：首页默认是不能关闭的哦！", {
               title:'关闭失败提示',
               icon:2,
               btnAlign:'c',
               skin: 'layui-layer-molv' //样式类名
               ,closeBtn: 0
           }, function(){
               layer.closeAll();
           });
       }else{
           var tabId = $(".layui-tab-title").find("li.layui-this").attr("lay-id");
           //循环左侧菜单ul,查找当前关闭的tab对应的li,进行样式修改
           $.each($("#secondMenu>.left-menu"),function (i,v) {
               var $this = $(this);
               $.each($this.find("li"),function (j,u) {
                   if($(this).find("a").attr("data-id")==tabId){
                       //查找到当前li,对其样式进行修改
                       $(this).removeClass("layui-this");
                       return false; //退出循环
                   }
               });
           });
           element.tabDelete(tab,tabId);//关闭当前tab
           var nextTabId = $(".layui-tab-title").find("li:last-child").attr("lay-id");
           //循环左侧菜单ul,查找当前关闭的tab对应的li,进行样式修改
           $.each($("#secondMenu>.left-menu"),function (i,v) {
               var flag = 0;//列表的顺序
               var $this = $(this);
               $.each($this.find("li"),function (j,u) {
                   if($(this).find("a").attr("data-id")==nextTabId){
                       //查找到当前li,对其样式进行修改
                       $(this).addClass("layui-this");
                       $(this).closest(".left-menu").show().siblings().hide();
                       flag =i;
                       $(".top-menu").find("li:eq("+flag+")").addClass("layui-this").siblings().removeClass("layui-this");//1级菜单添加样式
                       return false; //退出循环
                   }
               });
           });
           element.tabChange(tab,nextTabId);
       }
    });
    //2.关闭其他选项卡
    $("a[data-ename=closeOther]").on("click",function () {
       var obj =  $(".layui-tab-title").find("li");
       var currLayId =  $(".layui-tab-title").find("li.layui-this").attr("lay-id");
       if(obj && obj.length>2){
           $.each(obj,function (i,v) {
               var layId = $(this).attr("lay-id");
               if(layId=="11" || layId==currLayId){
                  //使当前的tab绑定上父级
                   $.each($("#secondMenu>.left-menu"),function (i,v) {
                       var flag = 0;//列表的顺序
                       var $this =$(this);
                       $.each($this.find("li"),function (j,u) {
                           if($(this).find("a").attr("data-id")==currLayId){
                               //查找到当前li,对其样式进行修改
                               $(this).addClass("layui-this");
                               $(this).closest(".left-menu").show().siblings().hide();
                               flag =i;
                               $(".top-menu").find("li:eq("+flag+")").addClass("layui-this").siblings().removeClass("layui-this");//1级菜单添加样式
                           }
                       });
                   });
               }else{
                   var tabId = $(this).attr("lay-id");
                   element.tabDelete(tab,tabId);
                   //循环左侧菜单ul,查找当前关闭的tab对应的li,进行样式修改
                   $.each($("#secondMenu>.left-menu"),function (i,v) {
                       var $this = $(this);
                       $.each($this.find("li"),function (j,u) {
                           if($(this).find("a").attr("data-id")==tabId){
                               //查找到当前li,对其样式进行修改
                               $(this).removeClass("layui-this");
                           }
                       });
                   });
               }
           })
       }else{
           layer.alert("温馨提示：当前无其他可关闭的选项卡！", {
               title:'关闭失败提示',
               icon:2,
               btnAlign:'c',
               skin: 'layui-layer-molv' //样式类名
               ,closeBtn: 0
           }, function(){
               layer.closeAll();
           });
       }
    });
    //关闭全部选项卡
    $("a[data-ename=closeAll]").on("click",function () {
        var obj =  $(".layui-tab-title").find("li");
        if(obj && obj.length>1){
            $.each(obj,function (i,v) {
                if($(this).attr("lay-id")!="11"){
                    var tabId = $(this).attr("lay-id");
                    element.tabDelete(tab,tabId);
                }else{
                    element.tabChange(tab,11);//首页保留
                }
                if(i==obj.length-1){
                  location.reload();
                }
            });

        }else if(obj.length==1){
            layer.alert("温馨提示：当前无其他可关闭的选项卡！", {
                title:'关闭失败提示',
                icon:2,
                btnAlign:'c',
                skin: 'layui-layer-molv' //样式类名
                ,closeBtn: 0
            }, function(){
                layer.closeAll();
            });
        }
    });
    //刷新最外层的frame框架
    $("a[data-ename=refreshAdmin]").on("click",function () {
        var index = layer.confirm('您确定要重新加载系统页面吗？', {
            title:'刷新提示',
            //skin:'layui-layer-molv',
            btn: ['确定','取消'] //按钮
        }, function(){
            if(top.frames.length>0){
                top.location.reload();
            }
        }, function(){
            //取消操作
            layer.close(index);
        });

    });
    $("#titleRight").on("click",function () {
       $(".layui-tab-title").animate({scrollLeft:0}, 'slow');
    });
    $("#titleLeft").on("click",function () {
        $(".layui-tab-title").animate({scrollLeft:200}, 'slow');
    });
    /*相关方法引入*/
    // 工具
    function _util(){
        var bar = $('.layui-fixbar');
        // 分辨率小于1024  使用内部工具组件
        if ($(window).width() < 1024) {
            $(".menu-flexible").hide();
            util.fixbar({
                bar1: '&#xe602;'
                , css: {left: 10, bottom: 54}
                , click: function (type) {
                    if (type === 'bar1') {
                        //iframe层
                        layer.open({
                            type: 1,                        // 类型
                            title: false,                   // 标题
                            offset: 'l',                    // 定位 左边
                            closeBtn: 0,                    // 关闭按钮
                            anim: 0,                        // 动画
                            shadeClose: true,               // 点击遮罩关闭
                            shade: 0.8,                     // 半透明
                            area: ['150px', '100%'],        // 区域
                            skin: 'my-mobile',              // 样式
                            content: $('body .my-side').html() // 内容
                        });
                    }
                    element.init();
                }
            });
            bar.removeClass('layui-hide');
            bar.addClass('layui-show');
        }else{
            $(".menu-flexible").show();
            bar.removeClass('layui-show');
            bar.addClass('layui-hide');
        }
    }
    // 导航栏收缩
    function navHide(t,st){
        var time = t ? t : 50;
        st ? localStorage.log = 1 : localStorage.log = 0;
        side.animate({'left':-200},time);
        body.animate({'left':0},time);
        footer.animate({'left':0},time);
    }
    // 导航栏展开
    function navShow(t,st){
        var time = t ? t : 50;
        st ? localStorage.log = 0 : localStorage.log = 1;
        side.animate({'left':0},time);
        body.animate({'left':200},time);
        footer.animate({'left':200},time);
    }
    //窗口自适应
    $(window).on('resize', function() {
        if($(this).width() > 1024){
            if(localStorage.log == 0){
                navShow();
            }
        }else{
            if(localStorage.log == 1){
                navHide();
            }
        }
        init();
    });
    // 监听控制content高度
    function init(){
        // 起始判断收缩还是展开
        if(localStorage.log == 0){
            navHide(100);
        }else{
            navShow(1);
        }
        // 工具
        _util();
       // 选项卡高度
       var  cardTitleHeight = $(document).find(".layui-tab[lay-filter='top-tab'] ul.layui-tab-title").height();
        // 需要减去的高度
       var height = $(window).height() - $('.layui-header').height() - cardTitleHeight - $('.layui-footer').height();
        // 设置每一个页面的高度
      $(document).find(".layui-tab[lay-filter='top-tab'] div.layui-tab-content").height( height-25);

    }
    //自定义表单规则
    form.verify({
        pass: [
            /^[\S]{8,12}$/
            , '密码必须8到12位，且不能出现空格'
        ],
        identical: function(value, item) { //value：表单的值、item：表单的DOM对象
           // console.log(item);
            var newPass = $("#newPass").val();
            if (value!==newPass) {
                return '两次输入的密码不一致，请重新输入';
            }
        },
        same:function(value,item){
            //value表单的输入值，item表单dom对象
            var oldPass =   $("#oldPass").val();
            if(value===oldPass){
                return '输入的新密码和旧密码一致，请重新输入';
            }
        },
        passwordLevel:function(value,item){
            var msg;
            $.ajax({
                url:ctxStatic+"checkPswMeter",
                method:"post",
                data:{"password":value},
                cache:false,
                async: false,
                dataType:"json",
                success: function (data) {
                    if(data.data){
                       if(data.data=="1"){
                           msg= "密码强度太低，请输入8位及以上包含数字、字母或者特殊字符的密码";
                        }
                    }
                }
            });
            if(msg){
                return msg;
            }
        }
    });
});

