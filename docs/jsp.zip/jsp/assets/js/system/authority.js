
layui.use(['element','layer','laypage','util','form'], function() {
	var element = layui.element(), layer = layui.layer,laypage = layui.laypage,form =layui.form(),$ = layui.jquery;
	var url = ctxStatic+"sysRole/getRoleList";

	
    //权限搜索功能
	form.on("submit(searchAuthList)",function () {
		var keywords = $("#sysAuth").find("input[name=keywords]").val();
		getAuthList(keywords);
	});
	$("input[name=keywords]").on("keyup",function (event) {
		if(event.keyCode==13){
			var keywords = $("#sysAuth").find("input[name=keywords]").val();
			getAuthList(keywords);
		}
	});

    //权限列表
	function getAuthList(keywords){
		checkedAuth =[];
		$.ajax({
			url:ctxStatic+"sysAuthority/getUrlList",
			method:"POST",
			data:{"pageNum":1,"pageSize":10000,"keywords":keywords},
			dataType:"json",
			beforeSend:function () {
			},
			success:function (data) {
				//填充表格
				if(data.data && data.data.length>0){
					var temp = [];
					$.each(data.data,function (i,v) {
						temp.push('<tr>' +
							'<td>'+(i+1)+'</td>' +
							' <td>'+escapeHtml(v.authorityName)+'</td>'+
							' <td>'+escapeHtml(v.authorityValue)+'</td>'+
							'</tr>');
					});
					$("#sysAuth").find("table tbody").empty().append(temp.join(""));
					form.render();
				}else{
					$("#sysAuth").find("table tbody").empty().append('<tr><td  class="text-center" colspan="4">暂无数据</td></tr>');
				}
			}
		});
	}
	getAuthList('');
	
	function getDifAuthList(){
		$.ajax({
			url:ctxStatic+"sysAuthority/differenceAuthority",
			method:"POST",
			data:{},
			dataType:"json",
			beforeSend:function () {
			},
			success:function (data) {
//				console.log(data);
				//填充表格
				if(data.difSysAuthority && data.difSysAuthority.length>0){
					var temp = [];
					$.each(data.difSysAuthority,function (i,v) {
						temp.push('<tr>' +
							'<td>'+(i+1)+'</td>' +
							' <td>'+escapeHtml(v.authorityName)+'</td>'+
							' <td>'+escapeHtml(v.authorityValue)+'</td>'+
							'</tr>');
					});
					$("#synAuthButton").prop("disabled", false);
					$("#synAuthButton").removeClass('layui-btn-disabled');
					$("#synAuth").find("table tbody").empty().append(temp.join(""));
				}else{
					$("#synAuthButton").prop("disabled", true);
					$("#synAuthButton").addClass('layui-btn-disabled');
					$("#synAuth").find("table tbody").empty().append('<tr><td  class="text-center" colspan="4">暂无数据</td></tr>');
				}
			}
		});
	}
	
	function synchronousAuth(){
		var loadIndex;
		$.ajax({
			url:ctxStatic+"sysAuthority/synchronousUrl",
			method:"POST",
			dataType:"json",
			beforeSend:function () {
				loadIndex = layer.load(2, {
					shade: [0.5,'#FFF'] //0.1透明度的白色背景
				});
			},
			success:function (data) {
				$("#synAuthButton").prop("disabled", true);
				$("#synAuthButton").addClass('layui-btn-disabled');
			},
			complete:function(XMLHttpRequest,status){
				getDifAuthList();
				layer.close(loadIndex);
			}
		});
	}
	
	$("#synAuthButton").on("click",function (data) {
		synchronousAuth();
	});
	
	element.on("tab(authTab)",function (data) {
		if(data.index==0){
			getAuthList('');
		}else if(data.index==1){
			getDifAuthList();
		}
	});
});
