
layui.use(['element','layer','laypage','util','form'], function() {
	var element = layui.element(), layer = layui.layer,laypage = layui.laypage,form =layui.form(),$ = layui.jquery;
	var layerHeight = $(window).height();//计算弹框高度使用
	var layerWidth = $(window).width();//计算弹框宽度使用
	var url = ctxStatic+"sysRole/getRoleList";
	var pageNum=1,pageSize=6;
	//加载角色列表
	rolePage(pageNum,pageSize,'');
	
	//搜索事件
	$("#searchRoleList").on("click",function(){
	    rolePage(pageNum,pageSize,$.trim($("#keywords").val()));
	});
	$("#keywords").on("keyup",function (event) {
		if(event.keyCode==13){
			rolePage(pageNum,pageSize,$.trim($("#keywords").val()));
		}
	});

	//角色添加事件
	var roleAddIndex= "";
	$("#addRole").on("click",function(){
		var height = parseInt(layerHeight*0.51);
		roleAddIndex=layer.open({
        type:1,
        title:"角色添加",
        skin: 'layui-layer-molv',
        content:$("#addRoleWin"),
        area: ['400px', height+'px']
        });
	});
	form.on('submit(confirmAddRole)',function (data) {
	  //console.log(data);
	  var roleName = $("#roleName").val();
	  var roleDesc = $("#roleDesc").html();
       $.ajax({
		   url:ctxStatic+"sysRole/addRole",
		   method:"POST",
		   data:data.field,
		   dataType:"json",
		   beforeSend:function () {
			   //发送请求之前应该置灰点击按钮
               $(data.elem).prop("disabled",true);
		   },
		   success:function (data) {
			  if(data.data=="0"){
				  //layer.msg(data.msg);//表示失败
				  msgTip(data.msg,data.data);
			  }else if(data.data=="1"){
				  //layer.msg(data.msg);//表示成功
				  msgTip(data.msg,data.data,true);
			  }
			   element.init();
		   },
		   complete:function () {
			   //请求完成，按钮置为可用
			  $(data.elem).prop("disabled",false);
			   layer.close(roleAddIndex);
		   }
	   });
		return false; //阻止表单跳转。如果需要表单跳转，去掉这段即可。
	});
    
	//删除角色事件
	$(document).on("click",".del-role", function () {
		//判断是否为最后一个，如果为最后一个那么就不能删除（提示信息），如果不为最后一个那么也提示是否要删除
		var $this = $(this);
		var id = $(this).closest("tr").find("td:first-child").find("xmp").html();//根据id删除
		var index = layer.confirm('您确定要删除吗？', {
			btn: ['确定','取消'] //按钮
		}, function(){
			//执行删除操作
			$.post(ctxStatic+"sysRole/delRole",{id:id},function (data) {
				if(data.data=="1"){
					//执行删除操作
					$this.closest("tr").remove();
					layer.close(index);
					msgTip(data.msg,data.data,true);
				}else if(data.data=="0"){
					msgTip(data.msg,data.data);
				}
				//layer.msg(data.msg);//提示内容
			},"json");

		}, function(){
			//取消操作
		});

	});

	//角色修改
	var roleEditorIndex;
	$(document).on("click",".editor-role",function(){
		var roleId = $(this).closest("tr").find("td:eq(0)").find("xmp").text();//roleId的值
		var roleName = $(this).closest("tr").find("td:eq(1)").text();//roleName的值
		var roleDesc = $(this).closest("tr").find("td:eq(2)").text();//roleName的值
		$("#editorRoleWin").find("input[name=roleId]").val(roleId);
		$("#editorRoleWin").find("input[name=roleName]").val(roleName);
		$("#editorRoleWin").find("textarea[name=roleDesc]").val(roleDesc);
        var height =parseInt(layerHeight*0.56);
		roleEditorIndex=layer.open({
			type:1,
			title:"角色编辑",
			skin: 'layui-layer-molv',
			content:$("#editorRoleWin"),
			area: ['400px', height+'px']
		});
	});
	form.on("submit(confirmEditorRole)",function (data) {
		//调用编辑的页面
		var roleId = $("#editorRoleWin").find("input[name=roleId]").val();
		var roleName = $("#editorRoleWin").find("input[name=roleName]").val();
		var roleDesc =$("#editorRoleWin").find("textarea[name=roleDesc]").val();
		$.ajax({
			url:ctxStatic+"sysRole/editRole",
			method:"POST",
			//data:{"roleId":roleId,"roleName":roleName,"roleDesc":roleDesc},
			data:data.field,
			dataType:"json",
			beforeSend:function () {
				//按钮置为不可用
				$(data.elem).prop("disabled",true);
			},
			success:function (data) {
				if(data.data=="0"){
					//layer.msg(data.msg);//表示失败
					msgTip(data.msg,data.data);
				}else if(data.data=="1"){
					//layer.msg(data.msg);//表示成功
					msgTip(data.msg,data.data);
					rolePage(pageNum,pageSize,$.trim($("#keywords").val()));
				}
				element.init();
			},
			complete:function () {
				//恢复按钮的可用功能
				$(data.elem).prop("disabled",false);
				layer.close(roleEditorIndex);
			}
		});
		return false;
	});

	//权限修改
	var globalKeywords = $("#editorAuthWin").find("input[name=keywords]").val();//全局变量
	var checkedAuth = [];//用于判断是否处于选中状态
	$(document).on("click",".editor-authority",function(){
		//获取权限列表
		var roleId = $(this).closest("tr").find("td:eq(0)").find("xmp").text();//roleId的值
		var keywords = $("#editorAuthWin").find("input[name=keywords]").val();
		$("#editorAuthWin").find("input[name=keywords]").attr("data-roleId",roleId);
		getAuthList(roleId,keywords);
		var width = parseInt(layerWidth*0.56);
		var height = parseInt(layerHeight*0.82);
	    var authEditorIndex=layer.open({
			type:1,
			offset:'15px',
			title:"权限修改",
			skin: 'layui-layer-molv',
			content:$("#editorAuthWin"),
			area: [width+'px', height+'px'],
			btnAlign: 'l',
			btn: ['确定', '取消'],
			yes: function(index, layero){
				//确定按钮的回调,ajax调用
				var authorityIds = "";
				var dom = $("#editorAuthWin").find("table tbody").find("input[name=checkbox]:checked");
				var flag = false;
				$.each(dom,function (i,v) {
					/*var $this = $(this).attr("data-id");//roleId的值
					$.each(checkedAuth,function (j,k) {
						//如果相同则不添加
						if(k==$this){
							flag=true;
							return false;
						}else{
							flag=false;
						}
					});*/
					var splitChar = "";//分隔符
				    if(!flag){
					   splitChar = (i==dom.length-1)?"":",";
					   authorityIds +=$(this).attr("data-id")+splitChar;
				    }

				});
				$.ajax({
					url:ctxStatic+"sysRole/editUserRole",
					method:"POST",
					data:{"roleId":roleId,"authorityIds":authorityIds,"keywords":globalKeywords},
					dataType:"json",
					beforeSend:function () {
					},
					success:function (data) {
						if(data.data=="0"){
							//修改角色失败
							//layer.msg(data.msg);
							msgTip(data.msg,0);
						}else if(data.data=="1"){
							//修改角色成功
							//layer.msg(data.msg);
							msgTip(data.msg,1,true);
						}
					},
					complete:function () {
						$("#editorAuthWin input[type=text]").val("");
						$("#editorAuthWin input[type=checkbox]").prop("checked",false);
						layer.close(authEditorIndex);
						element.init();
					}
				});

			},
			btn2: function(index, layero){
				//取消按钮的回调
				layer.close(authEditorIndex);
				$("#editorAuthWin input[type=text]").val("");
				$("#editorAuthWin input[type=checkbox]").prop("checked",false);
			}
		});
	});
	//复选框全选
	form.on('checkbox(allChoose)', function(data){
		var child = $(data.elem).parents('table').find('tbody input[type="checkbox"]');
		child.each(function(index, item){
			item.checked = data.elem.checked;
		});
		form.render('checkbox');
	});
    //权限搜索功能
	form.on("submit(searchAuthList)",function () {
		var roleId = $("#editorAuthWin").find("input[name=keywords]").attr("data-roleId");
		var keywords = $("#editorAuthWin").find("input[name=keywords]").val();
		globalKeywords = keywords;
		getAuthList(roleId,keywords);
	});
	$("#editorAuthWin input[name=keywords]").on("keyup",function (event) {
		if(event.keyCode==13){
			var roleId = $("#editorAuthWin").find("input[name=keywords]").attr("data-roleId");
			var keywords = $("#editorAuthWin").find("input[name=keywords]").val();
			globalKeywords = keywords;
			getAuthList(roleId,keywords);
		}
	});
	
	//菜单修改
	$(document).on("click",".editor-menu",function () {
		var roleId = $(this).closest("tr").find("td:eq(0)").find("xmp").text();//roleId的值
		treeObj = menuTree(roleId);
        //对比初始化值和当前选中的值
		var resIds = [];//操作之后的结果值
		var width = parseInt(layerWidth*0.56);
		var height = parseInt(layerHeight*0.80);
		var editorMenuIndex=layer.open({
			type:1,
			offset: '15px',
			title:"菜单关联",
			skin: 'layui-layer-molv',
			content:$("#editorMenuWin"),
			area: ['480px', height+'px'],
			btnAlign: 'l',
			btn: ['确定', '取消'],
			yes: function(index, layero){
				//获取当前的整个节点树，并对其进行操作
				var nodes = treeObj.getNodes();
				//一级菜单循环
				if(nodes && nodes.length){
					$.each(nodes,function (i,v) {
						if(v.checked){
						  resIds.push(v.id);
						}
						//二级菜单循环
						if(v.children && v.children.length){
							$.each(v.children,function (j,u) {
								if (u.checked) {
									resIds.push(u.id);
								}
								//三级菜单循环
								if(u.children && u.children.length){
									$.each(u.children,function (k,w) {
										if (w.checked) {
											resIds.push(w.id);
										}
									});
								}
							});
						}
					});
				}
				var menuIds = "";//需要往后台传递的值
				//比较初始化和操作之后的选中状态值
				if(resIds.length){
					$.each(resIds,function (i,v) {
					  var splitCode = i==resIds.length-1?"":",";
                       menuIds+=v+splitCode;
					});
				}
				$.ajax({
					url:ctxStatic+"sysRole/editUserMenu",
					method:"POST",
					data:{"roleId":roleId,"menuIds":menuIds},
					dataType:"json",
					beforeSend:function () {
					},
					success:function (data) {
						if(data.data=="0"){
							//修改菜单失败
							msgTip(data.msg,data.data);
						}else if(data.data=="1"){
							//修改角色成功
							//layer.msg(data.msg);
							msgTip(data.msg,data.data,true);
						}
					},
					complete:function () {
						layer.close(editorMenuIndex);
					}
				});

			},
			btn2: function(index, layero){
				//取消按钮的回调
				layer.close(editorMenuIndex);

			}
		});
	});

    //权限列表
	function getAuthList(roleId,keywords){
		checkedAuth =[];
		$.ajax({
			url:ctxStatic+"sysRole/getAuthorityList",
			method:"POST",
			data:{"roleId":roleId,"keywords":keywords},
			dataType:"json",
			beforeSend:function () {
			},
			success:function (data) {
				//填充表格
				if(data.data && data.data.length>0){
					var temp = [];
					$.each(data.data,function (i,v) {
						var isChecked = v.thisRole?"checked":"";
						if(v.thisRole){
							checkedAuth.push(v.id);
						}
						temp.push('<tr>' +
							'<td><input type="checkbox" name="checkbox" data-id="'+escapeHtml(v.id)+'" '+isChecked+' lay-skin="primary"/></td>' +
							' <td>'+escapeHtml(v.authorityName)+'</td>'+
							' <td>'+escapeHtml(v.authorityValue)+'</td>'+
							'</tr>');
					});
					$("#editorAuthWin").find("table tbody").empty().append(temp.join(""));
					form.render();
				}else{
					$("#editorAuthWin").find("table tbody").empty().append('<tr><td  class="text-center" colspan="4">暂无数据</td></tr>');
				}
			}
		});
	}
	//分页请求数据
	function rolePage(pageNum,pageSize,keywords){
		var index;
		$.ajax({
			url:url,
			method:"post",
			data:{pageNum:pageNum,pageSize:pageSize,keywords:keywords},
			cache:false,
			dataType:"json",
			beforeSend: function () {
				//调用之前进行加载
				index = layer.load(2, {
					shade: [0.5,'#fff'] //0.1透明度的白色背景
				});
			},
			success: function (data) {
				//执行列表加载并处理数据
				if(data.data && data.data.length){
					//编辑角色权限
					var editRoleDisable ="";
					if($.trim($("#authList .sysRole-editRole").html()) !="true"){
						//没有权限
						editRoleDisable = disabled="disabled";
					}
					//删除角色权限
					var delRoleDisable ="";
					if($.trim($("#authList .sysRole-delRole").html())!="true"){
						//没有权限
						delRoleDisable = disabled="disabled";
					}
					//菜单修改权限
					var editUserMenuDisable ="";
					if($.trim($("#authList .sysRole-editUserMenu").html())!="true"){
						//没有权限
						editUserMenuDisable = disabled="disabled";
					}
					var temp=[];
					$.each(data.data, function (i,v) {
						var menuDis='';
						var delDis='';
						
						if(v.roleId=='1'){
							menuDis='disabled="disabled"';
						}
						if(v.roleId=='1' || v.roleId=='001'){
							delDis='disabled="disabled"';
						}
						
						
						temp.push('<tr><td>'+((pageNum-1)*pageSize+i+1)+'<xmp style="display: none">'+v.roleId+'</xmp></td>' +
							'          <td><xmp>'+ v.roleName+'</xmp></td>' +
							'          <td><xmp>'+ v.roleDesc+'</xmp></td>' +
							'       <td><button '+menuDis+' class="layui-btn layui-btn-small editor-menu"  '+editUserMenuDisable+'><i class="layui-icon">&#xe624;</i>菜单</button>'+
							'           <button  '+delDis+' class="layui-btn layui-btn-small del-role" '+delRoleDisable+'><i class="layui-icon">&#xe640;</i>删除</button>' +
							'           <button  class="layui-btn layui-btn-small editor-role" '+editRoleDisable+'  lay-filter="editor"><i class="layui-icon">&#xe642;</i>编辑</button>' +
							'         </td>' +
							'    </tr>');
					});
					$("#roleList").empty().append(temp.join(""));
					$("#rolePage").show();
					laypage({
						cont: 'rolePage',
						pages: Math.ceil(data.count/pageSize),
						curr:pageNum,
						skip: true,
						jump:function(obj, first){
							if(!first){
								//layer.msg('第 '+ obj.curr +' 页');
								rolePage(obj.curr,pageSize,keywords);
							}
						}
					});
					element.init();
				}else{
					//layer.msg("数据为空！");
					$("#rolePage").hide();
					$("#roleList").empty().append('<tr><td  class="text-center" colspan="4">暂无数据</td></tr>');
				}
			},
			complete:function () {
				layer.close(index);
			}
		});
	}

	//自定义验证规则
	form.verify({
		roleDescLen:function (value,item) {
           //限制textarea长度
           if(value && !/d{0,50}/g.test(value)){
               return '角色描述不能超过50个字符';
		   }
		},
		roleNameLen:function (value,item) {
			//限制角色长度
			if(value && !/d{0,20}/g.test(value)){
				return '角色名称不能超过20个字符';
			}
		},
		roleName:function (value,item) {
			if(!new RegExp("^[a-zA-Z0-9_\u4e00-\u9fa5]+$").test(value)){
				return '输入内容不能包含空格等特殊字符';
			}
		},
		roleDesc:function (value,item) {
			if(!new RegExp("^[a-zA-Z0-9_\u4e00-\u9fa5\\s.。，,]*$").test(value)){
				return '输入内容不能包含特殊字符';
			}
		}

	});
});
//菜单tab
var treeObj;//全局的节点树对象
function menuTree(roleId){
	//roleId用于关联菜单的角色id,initMeunIds初始化保存选中的菜单，用于后面对比使用
	var setting = {
		check: {
			enable: true, //默认勾选值为checkbox
			chkStyle: "checkbox",
			chkboxType: { "Y": "ps", "N": "s" }
			//chkboxType:{ "Y" : "p", "N" : "s" }
		},
		callback: {
			onCheck: zTreeOnCheck
		}
	};
	$.ajax({
		url:ctxStatic+"sysRole/getMenuList",
		method:"post",
		data:{"roleId":roleId},
		cache:false,
		dataType:"json",
		beforeSend: function () {

		},
		success: function (data) {
			//执行列表加载并处理数据
			if(data.data && data.data.length){
				treeObj= $.fn.zTree.init($("#menuTree"), setting, data.data);
			}else{
				msgTip("菜单暂无数据",0);
			}
		},
		complete:function () {
			//调用完成之后的加载
		}
	});
	return treeObj;
}
//点击事件 treeId节点id，treeNode节点对象
function zTreeOnCheck(event, treeId, treeNode) {
	//操作节点

}