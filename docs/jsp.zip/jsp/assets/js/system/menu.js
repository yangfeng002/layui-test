
layui.use(['element','layer','laypage','util','form'], function() {
	var element = layui.element(), layer = layui.layer,form =layui.form(),$ = layui.jquery;

	//新增功能
	$(".btn-add").on("click",function () {
		$(".layui-btn-content").show();
		$("#menuForm").find("input[name=menuName]").val("");
		$("#menuForm").find("textarea[name=menuUrl]").val("");
		$("#menuForm").find("input[name=parentId]").val($(this).attr("data-id"));//新增的时候父ID的值为当前节点的id
		$("#menuForm").find("input[name=menuOrder]").val($(this).attr("data-order"));
		$("#menuForm").find("input[name=dataId]").val("");//dataId为空
		$("#menuForm").find("select").find("option:selected").prop("selected",false);
		$("#menuForm").find("select").find("option[value=icon-zhucaidan]").prop("selected",true); //icon图标
		form.render('select');
		$.each($(this).closest(".layui-form-item").find("button"),function (i,v) {
			$(this).removeClass("current");
		});
		$(this).addClass("current");
		if($(this).attr("data-level")=="0"){
			$("#iconBox").show();
		}else{
			$("#iconBox").hide();
		}
	});
	//编辑功能
	$(".btn-editor").on("click",function () {
		//将相关的值放到表单中
		$(".layui-btn-content").show();
		$("#menuForm").find("input[name=parentId]").val($(this).attr("data-parentId"));
		$("#menuForm").find("input[name=id]").val($(this).attr("data-id"));
		$("#menuForm").find("textarea[name=menuUrl]").val($(this).attr("data-url"));
		$("#menuForm").find("input[name=menuName]").val($(this).attr("data-name"));
		$("#menuForm").find("input[name=menuOrder]").val("");
		var icon = $(this).attr("data-icon");
		$("#menuForm").find("select").find("option:selected").prop("selected",false);
		$("#menuForm").find("select").find("option[value="+icon+"]").prop("selected",true); //icon图标
		form.render('select');//重新渲染一下
		$.each($(this).closest(".layui-form-item").find("button"),function (i,v) {
			$(this).removeClass("current");
		});
		$(this).addClass("current");
		if($(this).attr("data-level")=="1"){
			$("#iconBox").show();
		}else{
			$("#iconBox").hide();
		}
	});
	//删除功能
	$(".btn-del").on("click",function () {
		var id = $(this).attr("data-id");
		var index = layer.confirm('您确定要删除吗？', {
			btn: ['确定','取消'] //按钮
		}, function(){
			layer.close(index);
			//执行删除操作
			$.post(ctxStatic+"sysMenu/delMenu",{id:id},function (data) {
				if(data.data=="1"){
					//删除成功
					layer.close(index);
					msgTip(data.msg,data.data,true);
				}else if(data.data=="0"){
					//删除失败
					msgTip(data.msg,data.data);
				}
			},"json");

		}, function(){
			//取消操作
			layer.close(index);
		});
	});

	//提交事件
	form.on('submit(confirmmenuForm)',function (data) {
		var url= "";
		if($(".btn-add").hasClass("current")){
			url = ctxStatic+"sysMenu/addMenu"
		}else if($(".btn-editor").hasClass("current")){
			url = ctxStatic+"sysMenu/editMenu";
		}
		//console.log(data.field);
		var index;
		var ajaxTimeout = $.ajax({
		 url:url,
		 method:"post",
		 data:data.field,
		 cache:false,
		 dataType:"json",
		 timeout:6000,
		 beforeSend: function () {
			 index = layer.load(2, {
				 shade: [0.5,'#fff'] //0.1透明度的白色背景
			 });
			 //按钮置为不可用
			 $(data.elem).prop("disabled",true);
		 },
		 success: function (data) {
		    if(data.data=="0"){
				msgTip(data.msg,data.data);
			}else if(data.data=="1"){
				//操作成功
				msgTip(data.msg,data.data,true);
			}
		 },
		 complete:function (xhr,status) {
			 //请求完成之后按钮置恢复为可用
			  $(data.elem).prop("disabled",false);
			 //调用完成之后的加载
			 layer.close(index);
			 if(status=='timeout'){//超时,status还有success,error等值的情况
				 ajaxTimeout.abort();
				 // layer.msg("对不起，请求超时，请稍后访问");
				 msgTip("",3);
			 }
		 }
	  })
	});

	//自定义验证规则
	form.verify({
		menuUrlLen:function (value,item) {
			//限制textarea长度
			if(value && !/d{0,200}/g.test(value)){
				return 'url不能超过200个字符';
			}
		},
		filterUrl:function (value,item) {
			if(value){
				if(!new RegExp("^[a-zA-Z0-9\/:\{\}]+$").test(value)){
					return '输入内容只能是英文、数字、斜线、{}';
				}
			}
		},
		menuNameLen:function (value,item) {
			//限制角色长度
			if(value && !/d{0,20}/g.test(value)){
				return '名称不能超过20个字符';
			}
		},
		filterChar:function (value,item) {
			if(!new RegExp("^[a-zA-Z0-9_\u4e00-\u9fa5\\s·]+$").test(value)){
				return '输入内容不能包含特殊字符';
			}
		}
	});
});
//加载树形菜单
$(function(){
	var setting = {
		callback: {
			onClick: zTreeOnClick
		}
	};
	var url = ctxStatic+"sysMenu/getMenuTree";
	function menuTree(){
		$.ajax({
			url:url,
			method:"post",
			data:{},
			cache:false,
			dataType:"json",
			beforeSend: function () {

			},
			success: function (data) {
				//console.log(data);
				//执行列表加载并处理数据
				if(data.data && data.data.length){
					var height = $(window).height()-60-44-20;
					$("#menuTree").css({"max-height":height+"px"});
					$.fn.zTree.init($("#menuTree"), setting, data.data);
				}else{
					layer.msg("暂无菜单数据");
				}
			},
			complete:function () {
				//调用完成之后的加载
			}
		});
	}
	menuTree();
});
function zTreeOnClick(event, treeId, treeNode) {
	//console.log(treeNode);
	// 编辑和删除功能都是针对当前菜单，增加功能是针对的子菜单(此时需要传递order过去，编辑不需要传递order过去)
	$(".layui-btn-content").hide();
	var dataId = treeNode.id;//当前节点的id
	var parentId = treeNode.pId;//当前节点的父id
	var url = treeNode.menu_url;//当前节点url
	var dataOrder = 1;
	var dataName = treeNode.name;
	var dataIcon = treeNode.ico;
	var dataLevel = treeNode.level;
	if(treeNode.children && treeNode.children.length>0){
		//有子菜单，那么删除按钮隐藏
		$(".btn-del").hide();
		$.each(treeNode.children,function (i,v) {
			if(i==treeNode.children.length-1){
				dataOrder = v.order+1;
			}
		});
	}else{
		//没有子菜单删除按钮展示
		$(".btn-del").show();
	}
	/*编辑新增删除按钮控制*/
	$(".layui-btn-header").show();//按钮组展示
	if(treeNode.level=="0"){
		//根菜单不能出现编辑、删除功能、只有新增功能
        $(".btn-editor").hide();
		//$(".btn-del").hide();
	}else if(treeNode.level=="1" || treeNode.level=="2"){
		//1级2级菜单
		$(".btn-editor").show();
		$(".btn-add").show();
	}else if(treeNode.level=="3"){
		//三级菜单没有添加功能，可以编辑和删除
		$(".btn-editor").show();
		$(".btn-add").hide();
	}
	$(".btn-add").attr({"data-id":dataId,"data-parentId":parentId,"data-order":dataOrder,"data-level":dataLevel});//添加按钮
	$(".btn-editor").attr({"data-id":dataId,"data-name":dataName,"data-parentId":parentId,"data-url":url,"data-order":dataOrder,"data-icon":dataIcon,"data-level":dataLevel});//编辑按钮
	$(".btn-del").attr({"data-id":dataId,"data-parentId":parentId});//删除按钮

}