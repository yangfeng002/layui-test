
layui.use(['element','layer','laypage','util','form'], function() {
	var element = layui.element(), layer = layui.layer,laypage = layui.laypage,form =layui.form(),$ = layui.jquery;
	var layerHeight = $(window).height();//计算弹框高度使用
	var layerWidth = $(window).width();//计算弹框宽度使用
	//自定义验证规则
	form.verify({
		userDescLen:function (value,item) {
			//限制textarea长度
			if(value && !/d{0,50}/g.test(value)){
				return '用户描述不能超过50个字符';
			}
		},
		userNameLen:function (value,item) {
			//限制用户名长度
			if(value && !/d{0,20}/g.test(value)){
				return '用户名称不能超过20个字符';
			}
		},
		filterChar:function (value,item) {
			if(!new RegExp("^[a-zA-Z0-9_\u4e00-\u9fa5\\s.。，,]*$").test(value)){
				return '输入内容不能包含特殊字符';
			}
		},
		filterRealNameChar:function (value,item) {
			if(!new RegExp("^[a-zA-Z0-9\u4e00-\u9fa5]+$").test(value)){
				return '真实名只能输入数字和字母和汉字';
			}
		},
		filterNameChar:function (value,item) {
			if(!new RegExp("^[a-zA-Z0-9]+$").test(value)){
				return '用户名只能输入数字和字母';
			}
		},
		phoneNum: function (value,item) {
			//value表示输入的值，item：表单的DOM对象(移动的手机号段 139、138、137、136、135、134、159、150、151、158、157、188、187、152、182、147)
			var reg = /^(139|138|137|136|135|134|159|150|151|158|157|188|187|152|182|147)\d{8}$/;
			if(!reg.test(value)){
				return "请输入合法的移动手机号码";
			}
		},
		phoneNumCheck: function (value,item) {
			var msg='';
			var url = ctxStatic+"sysUser/checkUserNameOnly";
			$.ajax({
				url:url,
				method:"post",
				data:{userName:value},
				cache:false,
				async: false,
				dataType:"json",
				success: function (data) {
					if(!data.data){
						msg=data.msg;
					}
				}
			});
			if(msg){
				return msg;
			}

		}


	});
	var url = ctxStatic+"sysUser/getUserList";
	var pageNum=1,pageSize=6;
	userPage(pageNum,pageSize,'');
	
	//搜索事件
	$("#searchUser").on("click",function(){
	   userPage(pageNum,pageSize,$.trim($("#keywords").val()));
	});
	$("#keywords").on("keyup",function (event) {
		if(event.keyCode==13){
			userPage(pageNum,pageSize,$.trim($("#keywords").val()));
		}
	});
	var addWindowIndex;

	//添加用户事件
	$("#addUser").click(function(){
		var width = parseInt(layerWidth*0.32);
		var height = parseInt(layerHeight*0.84);
		addWindowIndex =layer.open({
			type:1,
			offset:'20px',
			title:"新增用户",
			skin: 'layui-layer-molv',
			content:$("#addUserWin"),
			area: ['480px', height+'px']
		});
	});
    form.on('submit(confirmAddUser)', function(data){
        var ajaxTimeout1 = $.ajax({
            url:ctxStatic+"sysUser/addUser",
            method:"post",
            data:data.field,
            cache:false,
            async:false,
            dataType:"json",
            timeout:6000,
            beforeSend: function () {
				//按钮置为不可用
				$(data.elem).prop("disabled",true);
            },
            success: function (data) {
                if(data.data==0){
                    //失败
                   //layer.msg(data.msg);
					msgTip(data.msg,data.data);
                }else if(data.data==1){
                    //成功刷新
					msgTip(data.msg,data.data,true);
                    //userPage(pageNum,pageSize,$("#keywords").val());
                }
                element.init();
            },
            complete : function(XMLHttpRequest,status){
				//按钮置为可用
				$(data.elem).prop("disabled",false);
				layer.close(addWindowIndex);
				//请求完成后最终执行参数
                if(status=='timeout'){//超时,status还有success,error等值的情况
                    ajaxTimeout1.abort();
                    layer.msg("对不起，请求超时，请稍后访问");
                }
            }
        });
        return false; //阻止表单跳转。如果需要表单跳转，去掉这段即可。
    });

	//编辑用户
	var userEditorIndex;
	$(document).on("click",".editor-user",function () {
		//获取到用户相关信息
		var userId = $(this).closest("tr").find("td:eq(0)").find("pre").text();//用户id
		var userName =  $(this).closest("tr").find("td:eq(1)").find("pre").text();//用户名
		var userAccount = $(this).closest("tr").find("td:eq(2)").find("pre").text();//用户真实名称
		var userDesc = $(this).closest("tr").find("td:eq(3)").find("pre").text();//用户描述
		var userPhone = $(this).closest("tr").find("td:eq(4)").find("pre").text();//用户手机号
		var userEmail = $(this).closest("tr").find("td:eq(5)").find("pre").text();//用户邮箱
		$("#editorUserForm").find("input[name=userId]").val(userId);
        $("#editorUserForm").find("input[name=userName]").val(userName);
		$("#editorUserForm").find("input[name=userAccount]").val(userAccount);
		$("#editorUserForm").find("textarea[name=userDesc]").val(userDesc);
		$("#editorUserForm").find("input[name=userPhone]").val(userPhone);
		$("#editorUserForm").find("input[name=userMail]").val(userEmail);

		var width = parseInt(layerWidth*0.32);//宽度设置
		var height = parseInt(layerHeight*0.75);//高度设置
		 userEditorIndex=layer.open({
			type:1,
			title:"编辑用户",
			skin: 'layui-layer-molv',
			content:$("#editorUserWin"),
			area: ['480px', height+'px'],
			btnAlign: 'l'
		});
	});
	form.on('submit(confirmEditorUser)', function(data){
		var ajaxTimeout1 = $.ajax({
			url:ctxStatic+"sysUser/editUser",
			method:"post",
			data:data.field,
			cache:false,
			async:false,
			dataType:"json",
			timeout:6000,
			beforeSend: function () {
				//按钮置为不可用
				$(data.elem).prop("disabled",true);
			},
			success: function (data) {
				if(data.data==0){
					//失败
					msgTip(data.msg,data.data)
				}else if(data.data==1){
					//成功
					msgTip(data.msg,data.data);
					userPage(pageNum,pageSize,$("#keywords").val());
				}
				element.init();
			},
			complete : function(XMLHttpRequest,status){
				//按钮置为可用
				$(data.elem).prop("disabled",false);
				layer.close(userEditorIndex);//请求完成后最终执行参数
				if(status=='timeout'){//超时,status还有success,error等值的情况
					ajaxTimeout1.abort();
					layer.msg("对不起，请求超时，请稍后访问");
				}
			}
			
		});
		return false; //阻止表单跳转。如果需要表单跳转，去掉这段即可。
	});

	//编辑角色
	var editorRoleIndex;
	var globalKeywords = $("#editorRoleWin").find("input[name=keywords]").val();
	$(document).on("click",".editor-role",function () {
		//获取权限列表
		var userId = $(this).closest("tr").find("td:eq(0)").find("pre").text();//roleId的值
		var keywords = $("#editorAuthWin").find("input[name=keywords]").val();
		$("#editorRoleWin").find("input[name=keywords]").attr("data-userId",userId);
		getRoleList(userId,keywords);
		var width = parseInt(layerWidth*0.52);
		var height = parseInt(layerHeight*0.78);
		editorRoleIndex=layer.open({
			type:1,
			offset: '15px',
			title:"角色修改",
			skin: 'layui-layer-molv',
			content:$("#editorRoleWin"),
			area: [width+'px', height+'px'],
			btnAlign: 'l',
			btn: ['确定', '取消'],
			yes:function () {
				//确定按钮
				var roleIds = "";
				var dom = $("#editorRoleWin").find("table tbody").find("input[name=checkbox]:checked");
				var flag = false;
				$.each(dom,function (i,v) {
					var splitChar = "";//分隔符
					if(!flag){
						splitChar = (i==dom.length-1)?"":",";
						roleIds +=$(this).attr("data-id")+splitChar;
					}
				});
				$.ajax({
					url:ctxStatic+"sysUser/editUserRole",
					method:"POST",
					data:{"userId":userId,"roleIds":roleIds,"keywords":globalKeywords},
					dataType:"json",
					beforeSend:function () {
					},
					success:function (data) {
						if(data.data=="0"){
							//修改角色失败
							//layer.msg(data.msg);
							msgTip(data.msg,data.data);
						}else{
							//修改角色成功
							//layer.msg(data.msg);
							msgTip(data.msg,data.data,true);
						}
						element.init();
					},
					complete:function () {
						layer.close(editorRoleIndex);
						$("#editorRoleWin input[type=text]").val("");
						$("#editorRoleWin input[type=checkbox]").prop("checked",false);
						globalKeywords = $("#editorRoleWin").find("input[name=keywords]").val();
					}
				});
			
			},
			btn2: function(index, layero){
				//取消按钮的回调
				layer.close(editorRoleIndex);
				$("#editorRoleWin input[type=text]").val("");
				$("#editorRoleWin input[type=checkbox]").prop("checked",false);
				globalKeywords = $("#editorRoleWin").find("input[name=keywords]").val();
			}
		});
	});
	//角色搜索功能
	form.on("submit(searchRoleList)",function () {
		var userId = $("#editorRoleWin").find("input[name=keywords]").attr("data-userId");
		var keywords = $("#editorRoleWin").find("input[name=keywords]").val();
		globalKeywords = keywords;
		getRoleList(userId,keywords);
	});
	$("#editorRoleWin input[name=keywords]").on("keyup",function (event) {
		if(event.keyCode==13){
			var userId = $("#editorRoleWin").find("input[name=keywords]").attr("data-userId");
			var keywords = $("#editorRoleWin").find("input[name=keywords]").val();
			globalKeywords = keywords;
			getRoleList(userId,keywords);
		}
	});

   //复选框全选
	form.on('checkbox(allChoose)', function(data){
		var child = $(data.elem).parents('table').find('tbody input[type="checkbox"]');
		child.each(function(index, item){
			item.checked = data.elem.checked;
		});
		form.render('checkbox');
	});

	//分页请求数据
	function userPage(pageNum,pageSize,keywords){
		$.ajax({
			url:url,
			method:"post",
			data:{pageNum:pageNum,pageSize:pageSize,keywords:keywords},
			cache:false,
			dataType:"json",
			beforeSend: function () {
				//调用之前进行加载
				index = layer.load(2, {
					shade: [0.5,'#FFF'] //0.1透明度的白色背景
				});
			},
			success: function (data) {
				//执行列表加载并处理数据
				if(data.data && data.data.length){
					//编辑用户权限
					var editUserDisable ="";
					if($.trim($("#authList .sysUser-editUser").html()) !="true"){
						//没有权限
						editUserDisable = disabled="disabled";
					}
					//删除用户权限
					var delUserDisable ="";
					if($.trim($("#authList .sysUser-delUser").html())!="true"){
						//没有权限
						delUserDisable = disabled="disabled";
					}
					//角色修改权限
					var editUserRoleDisable ="";
					if($.trim($("#authList .sysUser-editUserRole").html())!="true"){
						//没有权限
						editUserRoleDisable = disabled="disabled";
					}

					var temp=[];
					$.each(data.data, function (i,v) {
						temp.push('<tr><td>'+((pageNum-1)*pageSize+i+1)+'<pre style="display: none;">'+v.userId+'</pre></td><td><pre>'+ v.userName+'</pre></td>' +
							'         <td><pre>'+ v.userAccount+'</pre></td>' +
							'         <td><pre>'+ v.userDesc+'</pre></td>' +
							'         <td><pre>'+ v.userPhone+'</pre></td>' +
							'         <td><pre>'+ v.userMail+'</pre></td>' +
							'         <td name="'+v.userId+'">'+
							'           <button class="layui-btn layui-btn-small editor-role" '+editUserRoleDisable+'><i class="layui-icon">&#xe612;</i>角色</button> ' +
							'           <button class="layui-btn layui-btn-small del-user"  '+delUserDisable+'><i class="layui-icon">&#xe640;</i>删除</button>' +
							'           <button  class="layui-btn layui-btn-small editor-user" '+editUserDisable+'><i class="layui-icon">&#xe642;</i>编辑</button>' +
							'            ' +
							'         </td>' +
							'    </tr>');
					});
					$("#userList").empty().append(temp.join(""));
					$("#userPage").show();
					laypage({
						cont: 'userPage',
						pages: Math.ceil(data.count/pageSize),
						curr:pageNum,
						skip: true,
						jump:function(obj, first){
							if(!first){
								//layer.msg('第 '+ obj.curr +' 页');
								userPage(obj.curr,pageSize,keywords);
							}
						}
					});
					element.init();
					initOn();
				}else{
					//layer.msg("数据为空！");
					$("#userPage").hide();
					$("#userList").empty().append("<tr><td class='text-center' colspan='7'>暂无数据</td></tr>");
				}
			},
			complete:function(XMLHttpRequest,status){
				layer.close(index);
			}
		});
	}
	//初始化列表内按钮事件
	function initOn(){
		//删除用户
		$(".del-user").on("click",function() {
			var obj=this;
			var index = layer.confirm('您确定要删除吗？', {
				btn: ['确定','取消'] //按钮
			}, function(){
				//确定退出
				//console.log($(obj).parent('td').attr('name'));
				var url = ctxStatic+"sysUser/delUser";
				var id=$(obj).parent('td').attr('name');
				$.ajax({
					url:url,
					method:"post",
					data:{id:id},
					cache:false,
					dataType:"json",
					success: function (data) {
						//layer.msg(data.msg);
						if(data.data=="0"){
							//删除失败
							msgTip(data.msg,data.data);
						}else if(data.data=="1"){
							//删除成功
							userPage(pageNum,pageSize,$("#keywords").val());//重载数据
							msgTip(data.msg,data.data,true);
						}
					},
					complete:function () {
						layer.close(index);
					}
				});
				//layer.close(index);
			}, function(){
				//取消操作
			});
		});
	}
	//角色列表
	function getRoleList(userId,keywords){
		checkedRole =[];
		$.ajax({
			url:ctxStatic+"sysUser/getRoleList",
			method:"POST",
			data:{"userId":userId,"keywords":keywords},
			dataType:"json",
			beforeSend:function () {
			},
			success:function (data) {
				//填充表格
				if(data.data && data.data.length>0){
					var temp = [];
					$.each(data.data,function (i,v) {
						var isChecked = v.isThisUser?"checked":"";
						if(v.isThisUser){
							checkedRole.push(v.id);
						}
						temp.push('<tr>' +
							'<td><input type="checkbox" name="checkbox" data-id="'+escapeHtml(v.roleId)+'" '+isChecked+' lay-skin="primary"/></td>' +
							' <td>'+escapeHtml(v.roleName)+'</td>'+
							' <td>'+escapeHtml(v.roleDesc)+'</td>'+
							'</tr>');
					});
					$("#editorRoleWin").find("table tbody").empty().append(temp.join(""));
					form.render();
				}else{
					$("#editorRoleWin").find("table tbody").empty().append('<tr><td  class="text-center" colspan="4">暂无数据</td></tr>');
				}
			},
			complete:function () {
				//完成之后的代码
			}
		});
	}
});
